(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[1248],{62898:function(e,t,r){"use strict";r.d(t,{Z:function(){return i}});var n=r(2265),a={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),i=(e,t)=>{let r=(0,n.forwardRef)(({color:r="currentColor",size:i=24,strokeWidth:c=2,absoluteStrokeWidth:o,className:l="",children:d,...u},h)=>(0,n.createElement)("svg",{ref:h,...a,width:i,height:i,stroke:r,strokeWidth:o?24*Number(c)/Number(i):c,className:["lucide",`lucide-${s(e)}`,l].join(" "),...u},[...t.map(([e,t])=>(0,n.createElement)(e,t)),...Array.isArray(d)?d:[d]]));return r.displayName=`${e}`,r}},92457:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(62898).Z)("BarChart3",[["path",{d:"M3 3v18h18",key:"1s2lah"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]])},3021:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(62898).Z)("Bell",[["path",{d:"M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9",key:"1qo2s2"}],["path",{d:"M10.3 21a1.94 1.94 0 0 0 3.4 0",key:"qgo35s"}]])},71738:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(62898).Z)("CreditCard",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]])},38438:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(62898).Z)("Image",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]])},65883:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(62898).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},32176:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(62898).Z)("MessageCircle",[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}]])},37189:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(62898).Z)("PlayCircle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polygon",{points:"10 8 16 12 10 16 10 8",key:"1cimsy"}]])},49036:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(62898).Z)("Shield",[["path",{d:"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10",key:"1irkt0"}]])},25750:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(62898).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},34962:function(e,t,r){Promise.resolve().then(r.bind(r,66424))},66424:function(e,t,r){"use strict";r.r(t),r.d(t,{default:function(){return b}});var n=r(57437),a=r(24033),s=r(92457),i=r(25750),c=r(71738),o=r(3021),l=r(38438),d=r(32176),u=r(37189),h=r(49036),f=r(65883);let m=[{href:"/administracaosecr/dashboard",label:"Dashboard",icon:s.Z},{href:"/administracaosecr/usuarios",label:"Todos os Usu\xe1rios",icon:i.Z},{href:"/administracaosecr/assinantes",label:"Usu\xe1rios Assinantes",icon:c.Z},{href:"/administracaosecr/avisos",label:"Central de Avisos",icon:o.Z},{href:"/administracaosecr/banners",label:"Banners",icon:l.Z},{href:"/administracaosecr/chat",label:"Chat de Suporte",icon:d.Z},{href:"/administracaosecr/tutoriais",label:"Tutoriais",icon:u.Z}];function x(){let e=(0,a.usePathname)(),t=(0,a.useRouter)();return(0,n.jsx)("aside",{className:"fixed left-0 top-0 h-screen w-64 bg-brand-royal border-r border-white/10 shadow-lg z-50 hidden lg:block",children:(0,n.jsxs)("div",{className:"p-6",children:[(0,n.jsx)("div",{className:"mb-8",children:(0,n.jsxs)("div",{className:"flex items-center gap-3 mb-2",children:[(0,n.jsx)("div",{className:"p-2 bg-brand-aqua/20 rounded-xl",children:(0,n.jsx)(h.Z,{size:24,className:"text-brand-aqua"})}),(0,n.jsxs)("div",{children:[(0,n.jsx)("h2",{className:"text-lg font-display font-bold text-brand-clean",children:"Admin Panel"}),(0,n.jsx)("p",{className:"text-xs text-brand-clean/60",children:"PLENIPAY"})]})]})}),(0,n.jsx)("nav",{className:"space-y-2 mb-8",children:m.map(r=>{let a=r.icon,s=e===r.href||"/administracaosecr/dashboard"!==r.href&&(null==e?void 0:e.startsWith(r.href));return(0,n.jsxs)("button",{onClick:()=>t.push(r.href),className:"w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-smooth text-left ".concat(s?"bg-brand-aqua text-brand-midnight shadow-lg":"text-brand-clean hover:bg-white/10 hover:text-brand-aqua"),children:[(0,n.jsx)(a,{size:20,strokeWidth:2}),(0,n.jsx)("span",{className:"font-medium",children:r.label})]},r.href)})}),(0,n.jsxs)("button",{onClick:()=>{document.cookie="admin_token=; path=/; max-age=0",t.push("/administracaosecr/login")},className:"w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-smooth text-left text-brand-clean hover:bg-red-900/20 hover:text-red-400",children:[(0,n.jsx)(f.Z,{size:20,strokeWidth:2}),(0,n.jsx)("span",{className:"font-medium",children:"Sair"})]})]})})}var y=r(2265);function p(e){let{children:t}=e,r=(0,a.useRouter)(),s=(0,a.usePathname)(),[i,c]=(0,y.useState)(!0),[o,l]=(0,y.useState)(!1);return((0,y.useEffect)(()=>{if("/administracaosecr/login"===s){l(!0),c(!1);return}(async()=>{try{if(!document.cookie.split(";").find(e=>e.trim().startsWith("admin_token="))||!(await fetch("/api/admin/verify",{method:"GET",credentials:"include"})).ok){r.replace("/administracaosecr/login");return}l(!0),c(!1)}catch(e){r.replace("/administracaosecr/login")}})()},[s,r]),"/administracaosecr/login"===s)?(0,n.jsx)(n.Fragment,{children:t}):i||!o?(0,n.jsx)("div",{className:"min-h-screen bg-brand-midnight flex items-center justify-center",children:(0,n.jsx)("div",{className:"text-brand-clean",children:"Verificando autentica\xe7\xe3o..."})}):(0,n.jsx)(n.Fragment,{children:t})}function b(e){let{children:t}=e,r=(0,a.usePathname)();return"/administracaosecr/login"===r||"/administracaosecr"===r?(0,n.jsx)(n.Fragment,{children:t}):(0,n.jsx)(p,{children:(0,n.jsxs)("div",{className:"min-h-screen bg-brand-midnight",children:[(0,n.jsx)(x,{}),(0,n.jsx)("main",{className:"lg:ml-64 p-4 lg:p-8",children:t})]})})}},30622:function(e,t,r){"use strict";var n=r(2265),a=Symbol.for("react.element"),s=Symbol.for("react.fragment"),i=Object.prototype.hasOwnProperty,c=n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,o={key:!0,ref:!0,__self:!0,__source:!0};function l(e,t,r){var n,s={},l=null,d=null;for(n in void 0!==r&&(l=""+r),void 0!==t.key&&(l=""+t.key),void 0!==t.ref&&(d=t.ref),t)i.call(t,n)&&!o.hasOwnProperty(n)&&(s[n]=t[n]);if(e&&e.defaultProps)for(n in t=e.defaultProps)void 0===s[n]&&(s[n]=t[n]);return{$$typeof:a,type:e,key:l,ref:d,props:s,_owner:c.current}}t.Fragment=s,t.jsx=l,t.jsxs=l},57437:function(e,t,r){"use strict";e.exports=r(30622)},24033:function(e,t,r){e.exports=r(15313)}},function(e){e.O(0,[2971,4938,1744],function(){return e(e.s=34962)}),_N_E=e.O()}]);