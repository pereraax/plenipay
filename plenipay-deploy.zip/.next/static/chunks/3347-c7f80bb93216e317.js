(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[3347,4599],{11981:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("AlertCircle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]])},92457:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("BarChart3",[["path",{d:"M3 3v18h18",key:"1s2lah"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]])},3021:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("Bell",[["path",{d:"M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9",key:"1qo2s2"}],["path",{d:"M10.3 21a1.94 1.94 0 0 0 3.4 0",key:"qgo35s"}]])},20173:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("CheckCircle2",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]])},6141:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},71738:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("CreditCard",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]])},99670:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("Eye",[["path",{d:"M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z",key:"rwhkz3"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},38438:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("Image",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]])},74056:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("Info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]])},65883:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},32176:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("MessageCircle",[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}]])},37189:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("PlayCircle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polygon",{points:"10 8 16 12 10 16 10 8",key:"1cimsy"}]])},9883:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},92295:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("Save",[["path",{d:"M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z",key:"1owoqh"}],["polyline",{points:"17 21 17 13 7 13 7 21",key:"1md35c"}],["polyline",{points:"7 3 7 8 15 8",key:"8nz8an"}]])},49036:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("Shield",[["path",{d:"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10",key:"1irkt0"}]])},53589:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("SquarePen",[["path",{d:"M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",key:"1m0v6g"}],["path",{d:"M18.375 2.625a2.121 2.121 0 1 1 3 3L12 15l-4 1 1-4Z",key:"1lpok0"}]])},45367:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},31541:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("Upload",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"17 8 12 3 7 8",key:"t8dd8p"}],["line",{x1:"12",x2:"12",y1:"3",y2:"15",key:"widbto"}]])},25750:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n(62898).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},66424:function(e,t,n){"use strict";n.r(t),n.d(t,{default:function(){return k}});var a=n(57437),i=n(24033),r=n(92457),c=n(25750),s=n(71738),l=n(3021),o=n(38438),d=n(32176),u=n(37189),h=n(49036),m=n(65883);let y=[{href:"/administracaosecr/dashboard",label:"Dashboard",icon:r.Z},{href:"/administracaosecr/usuarios",label:"Todos os Usu\xe1rios",icon:c.Z},{href:"/administracaosecr/assinantes",label:"Usu\xe1rios Assinantes",icon:s.Z},{href:"/administracaosecr/avisos",label:"Central de Avisos",icon:l.Z},{href:"/administracaosecr/banners",label:"Banners",icon:o.Z},{href:"/administracaosecr/chat",label:"Chat de Suporte",icon:d.Z},{href:"/administracaosecr/tutoriais",label:"Tutoriais",icon:u.Z}];function f(){let e=(0,i.usePathname)(),t=(0,i.useRouter)();return(0,a.jsx)("aside",{className:"fixed left-0 top-0 h-screen w-64 bg-brand-royal border-r border-white/10 shadow-lg z-50 hidden lg:block",children:(0,a.jsxs)("div",{className:"p-6",children:[(0,a.jsx)("div",{className:"mb-8",children:(0,a.jsxs)("div",{className:"flex items-center gap-3 mb-2",children:[(0,a.jsx)("div",{className:"p-2 bg-brand-aqua/20 rounded-xl",children:(0,a.jsx)(h.Z,{size:24,className:"text-brand-aqua"})}),(0,a.jsxs)("div",{children:[(0,a.jsx)("h2",{className:"text-lg font-display font-bold text-brand-clean",children:"Admin Panel"}),(0,a.jsx)("p",{className:"text-xs text-brand-clean/60",children:"PLENIPAY"})]})]})}),(0,a.jsx)("nav",{className:"space-y-2 mb-8",children:y.map(n=>{let i=n.icon,r=e===n.href||"/administracaosecr/dashboard"!==n.href&&(null==e?void 0:e.startsWith(n.href));return(0,a.jsxs)("button",{onClick:()=>t.push(n.href),className:"w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-smooth text-left ".concat(r?"bg-brand-aqua text-brand-midnight shadow-lg":"text-brand-clean hover:bg-white/10 hover:text-brand-aqua"),children:[(0,a.jsx)(i,{size:20,strokeWidth:2}),(0,a.jsx)("span",{className:"font-medium",children:n.label})]},n.href)})}),(0,a.jsxs)("button",{onClick:()=>{document.cookie="admin_token=; path=/; max-age=0",t.push("/administracaosecr/login")},className:"w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-smooth text-left text-brand-clean hover:bg-red-900/20 hover:text-red-400",children:[(0,a.jsx)(m.Z,{size:20,strokeWidth:2}),(0,a.jsx)("span",{className:"font-medium",children:"Sair"})]})]})})}var p=n(2265);function x(e){let{children:t}=e,n=(0,i.useRouter)(),r=(0,i.usePathname)(),[c,s]=(0,p.useState)(!0),[l,o]=(0,p.useState)(!1);return((0,p.useEffect)(()=>{if("/administracaosecr/login"===r){o(!0),s(!1);return}(async()=>{try{if(!document.cookie.split(";").find(e=>e.trim().startsWith("admin_token="))||!(await fetch("/api/admin/verify",{method:"GET",credentials:"include"})).ok){n.replace("/administracaosecr/login");return}o(!0),s(!1)}catch(e){n.replace("/administracaosecr/login")}})()},[r,n]),"/administracaosecr/login"===r)?(0,a.jsx)(a.Fragment,{children:t}):c||!l?(0,a.jsx)("div",{className:"min-h-screen bg-brand-midnight flex items-center justify-center",children:(0,a.jsx)("div",{className:"text-brand-clean",children:"Verificando autentica\xe7\xe3o..."})}):(0,a.jsx)(a.Fragment,{children:t})}function k(e){let{children:t}=e,n=(0,i.usePathname)();return"/administracaosecr/login"===n||"/administracaosecr"===n?(0,a.jsx)(a.Fragment,{children:t}):(0,a.jsx)(x,{children:(0,a.jsxs)("div",{className:"min-h-screen bg-brand-midnight",children:[(0,a.jsx)(f,{}),(0,a.jsx)("main",{className:"lg:ml-64 p-4 lg:p-8",children:t})]})})}},34599:function(e,t,n){"use strict";n.d(t,{createClient:function(){return i}});var a=n(70889);function i(){return(0,a.createBrowserClient)("https://frhxqgcqmxpjpnghsvoe.supabase.co","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZyaHhxZ2NxbXhwanBuZ2hzdm9lIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM2NTM3NTYsImV4cCI6MjA3OTIyOTc1Nn0.p1OxLRA5DKgvetuy-IbCfYClNSjrvK6fm43aZNX3T7I",{cookies:{getAll:()=>document.cookie.split(";").map(e=>e.trim()).filter(e=>e.length>0).map(e=>{let t=e.indexOf("=");if(-1===t)return{name:e,value:""};let n=e.substring(0,t).trim(),a=e.substring(t+1).trim();try{return{name:n,value:decodeURIComponent(a)}}catch(e){return{name:n,value:a}}}),setAll(e){e.forEach(e=>{let{name:t,value:n,options:a}=e,i="".concat(t,"=").concat(encodeURIComponent(n));(null==a?void 0:a.maxAge)&&(i+="; max-age=".concat(a.maxAge)),(null==a?void 0:a.domain)&&(i+="; domain=".concat(a.domain)),(null==a?void 0:a.path)?i+="; path=".concat(a.path):i+="; path=/",(null==a?void 0:a.secure)&&(i+="; secure"),(null==a?void 0:a.sameSite)&&(i+="; samesite=".concat(a.sameSite)),document.cookie=i})}}})}},24033:function(e,t,n){e.exports=n(15313)}}]);