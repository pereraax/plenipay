'use client'

import { useState, useEffect } from 'react'
import { Bell } from 'lucide-react'
import { useRouter } from 'next/navigation'

interface Notification {
  id: string
  message: string
  type: 'success' | 'info' | 'warning'
  timestamp: Date
  read?: boolean
}

export default function NotificationBell() {
  const [isOpen, setIsOpen] = useState(false)
  const [notifications, setNotifications] = useState<Notification[]>([])
  const router = useRouter()

  useEffect(() => {
    // Carregar notificações do localStorage apenas uma vez
    const saved = localStorage.getItem('notifications')
    if (saved) {
      try {
        const parsed = JSON.parse(saved).map((n: any) => ({
          ...n,
          timestamp: new Date(n.timestamp),
          read: n.read !== undefined ? n.read : false // Garantir que todas tenham o campo read
        }))
        setNotifications(parsed)
      } catch (e) {
        console.error('Erro ao carregar notificações:', e)
      }
    }

    // Carregar avisos admin
    async function carregarAvisosAdmin() {
      try {
        const { createClient } = await import('@/lib/supabase/client')
        const supabase = createClient()
        const { data: { user } } = await supabase.auth.getUser()

        if (!user) return

        const response = await fetch(`/api/admin/avisos?userId=${user.id}`, {
          cache: 'no-store'
        })

        if (response.ok) {
          const data = await response.json()
          const avisos = data.avisos || []

          // Adicionar avisos admin como notificações
          const avisosNotificacoes = avisos.map((aviso: any) => ({
            id: `admin-${aviso.id}`,
            message: aviso.titulo,
            type: aviso.tipo === 'error' ? 'warning' : aviso.tipo,
            timestamp: new Date(aviso.created_at),
            read: false
          }))

          if (avisosNotificacoes.length > 0) {
            setNotifications((prev) => {
              const existingIds = new Set(prev.map(n => n.id))
              const novos = avisosNotificacoes.filter((n: any) => !existingIds.has(n.id))
              const updated = [...novos, ...prev].slice(0, 10)
              localStorage.setItem('notifications', JSON.stringify(updated))
              return updated
            })
          }
        }
      } catch (error) {
        console.error('Erro ao carregar avisos admin:', error)
      }
    }

    carregarAvisosAdmin()
  }, []) // Array vazio - executa apenas uma vez

  useEffect(() => {
    // Listener para novas notificações
    const handleNotification = (event: CustomEvent) => {
      const newNotification: Notification = {
        id: Date.now().toString(),
        message: event.detail.message,
        type: event.detail.type || 'info',
        timestamp: new Date(),
        read: false
      }
      
      setNotifications((prev) => {
        const updated = [newNotification, ...prev].slice(0, 10) // Máximo 10
        localStorage.setItem('notifications', JSON.stringify(updated))
        return updated
      })
    }

    window.addEventListener('notification' as any, handleNotification as EventListener)
    
    return () => {
      window.removeEventListener('notification' as any, handleNotification as EventListener)
    }
  }, []) // Array vazio - listener é criado apenas uma vez

  // Marcar todas as notificações como lidas quando o dropdown é aberto
  useEffect(() => {
    if (isOpen) {
      setNotifications((prev) => {
        const hasUnread = prev.some(n => !n.read)
        if (hasUnread) {
          const updated = prev.map(n => ({ ...n, read: true }))
          localStorage.setItem('notifications', JSON.stringify(updated))
          return updated
        }
        return prev
      })
    }
  }, [isOpen])

  const unreadCount = notifications.filter(n => !n.read).length

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'border-green-500 dark:border-green-400'
      case 'warning':
        return 'border-orange-500 dark:border-orange-400'
      default:
        return 'border-brand-aqua dark:border-brand-aqua'
    }
  }

  const clearNotifications = () => {
    setNotifications([])
    localStorage.removeItem('notifications')
  }

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 text-brand-midnight dark:text-brand-clean hover:bg-brand-clean dark:hover:bg-white/10 rounded-xl transition-smooth"
      >
        <Bell size={24} strokeWidth={2} />
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 bg-brand-aqua text-brand-midnight dark:text-brand-midnight text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <>
          <div
            className="fixed z-[90] bg-transparent"
            onClick={() => setIsOpen(false)}
            style={{ 
              left: '256px', 
              top: 0,
              right: 0,
              bottom: 0,
              width: 'calc(100% - 256px)'
            }}
          />
          <div className="absolute right-0 top-12 w-80 bg-white dark:bg-brand-midnight rounded-2xl shadow-2xl z-[95] max-h-96 overflow-hidden flex flex-col animate-scale-up pointer-events-auto border-2 border-gray-200 dark:border-brand-aqua/30">
            <div className="p-4 border-b border-gray-200 dark:border-brand-aqua/20 flex items-center justify-between bg-gradient-to-r from-brand-aqua/10 to-brand-royal/10 dark:from-brand-midnight dark:to-brand-royal/50">
              <h3 className="font-display font-bold text-lg text-brand-midnight dark:text-brand-clean">
                Notificações
              </h3>
              {notifications.length > 0 && (
                <button
                  onClick={clearNotifications}
                  className="text-xs font-semibold text-brand-aqua hover:text-brand-midnight dark:hover:text-brand-clean transition-smooth px-2 py-1 rounded-lg hover:bg-brand-aqua/10 dark:hover:bg-brand-aqua/20"
                >
                  Limpar todas
                </button>
              )}
            </div>
            <div className="overflow-y-auto flex-1 bg-white dark:bg-brand-royal/80">
              {notifications.length === 0 ? (
                <div className="p-8 text-center">
                  <Bell size={32} className="mx-auto mb-3 text-brand-midnight/30 dark:text-brand-clean/30" />
                  <p className="text-brand-midnight/70 dark:text-brand-clean/70 text-sm font-medium">
                    Nenhuma notificação
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-gray-100 dark:divide-white/10">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 border-l-4 ${getNotificationColor(notification.type)} bg-white dark:bg-brand-royal/60 hover:bg-gray-50 dark:hover:bg-brand-royal/80 transition-smooth`}
                    >
                      <p className="text-sm font-medium text-brand-midnight dark:text-brand-clean leading-relaxed">
                        {notification.message}
                      </p>
                      <p className="text-xs text-brand-midnight/60 dark:text-brand-clean/60 mt-2 font-medium">
                        {notification.timestamp.toLocaleTimeString('pt-BR', {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  )
}

// Função helper para criar notificações
export function createNotification(message: string, type: 'success' | 'info' | 'warning' = 'info') {
  const event = new CustomEvent('notification', {
    detail: { message, type }
  })
  window.dispatchEvent(event)
}

