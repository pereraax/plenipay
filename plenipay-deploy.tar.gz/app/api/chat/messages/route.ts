import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json(
        { error: 'Não autenticado' },
        { status: 401 }
      )
    }

    // Buscar mensagens do usuário
    const { data: messages, error } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: true })

    if (error) {
      console.error('Erro ao buscar mensagens:', error)
      return NextResponse.json(
        { error: 'Erro ao buscar mensagens' },
        { status: 500 }
      )
    }

    // Verificar se a conversa está finalizada
    const { data: conversation } = await supabase
      .from('chat_conversations')
      .select('is_closed')
      .eq('user_id', user.id)
      .single()

    const isClosed = conversation?.is_closed || false

    return NextResponse.json({ 
      messages: messages || [],
      isClosed 
    })
  } catch (error: any) {
    console.error('Erro inesperado:', error)
    return NextResponse.json(
      { error: 'Erro inesperado ao buscar mensagens' },
      { status: 500 }
    )
  }
}

