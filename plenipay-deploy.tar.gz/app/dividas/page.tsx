'use client'

import { useEffect, useState } from 'react'
import Sidebar from '@/components/Sidebar'
import MobileMenu from '@/components/MobileMenu'
import DividasLista from '@/components/DividasLista'
import PlanoGuard from '@/components/PlanoGuard'
import { obterDividas } from '@/lib/actions'
import { Loader2 } from 'lucide-react'

export default function DividasPage() {
  const [dividas, setDividas] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  const carregarDividas = async () => {
    try {
      setLoading(true)
      const result = await obterDividas()
      setDividas(result?.data || [])
    } catch (error) {
      console.error('Erro ao carregar dívidas:', error)
      setDividas([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    carregarDividas()
    
    // Listener para recarregar quando a página receber foco (voltar de outra página)
    const handleFocus = () => {
      carregarDividas()
    }
    
    window.addEventListener('focus', handleFocus)
    
    return () => {
      window.removeEventListener('focus', handleFocus)
    }
  }, [])

  return (
    <div className="min-h-screen bg-brand-clean dark:bg-brand-midnight">
      <MobileMenu />
      <Sidebar />
      <main className="lg:ml-64 p-4 lg:p-8 dark:bg-brand-midnight">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-display font-bold text-brand-midnight dark:text-brand-clean mb-8">
            Dívidas
          </h1>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="animate-spin text-brand-aqua" size={32} />
            </div>
          ) : (
            <PlanoGuard feature="Gerenciamento de Dívidas" planoNecessario="basico">
              <DividasLista dividas={dividas} />
            </PlanoGuard>
          )}
        </div>
      </main>
    </div>
  )
}

