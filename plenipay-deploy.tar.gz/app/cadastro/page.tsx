'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { signUp } from '@/lib/auth'
import { createNotification } from '@/components/NotificationBell'
import { ArrowLeft, Eye, EyeOff } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'
import ModalConfirmarEmail from '@/components/ModalConfirmarEmail'
import AnimatedBackground from '@/components/AnimatedBackground'

export default function CadastroPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const plano = (searchParams.get('plano') as 'teste' | 'basico' | 'premium') || 'teste'
  
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showModalConfirmacao, setShowModalConfirmacao] = useState(false)
  const [emailCadastrado, setEmailCadastrado] = useState('')

  // Debug: monitorar mudanças no estado do modal
  useEffect(() => {
    console.log('🔔 showModalConfirmacao mudou para:', showModalConfirmacao)
    console.log('📧 emailCadastrado:', emailCadastrado)
  }, [showModalConfirmacao, emailCadastrado])
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    senha: '',
    confirmarSenha: '',
    whatsapp: '',
  })

  const formatarTelefone = (value: string) => {
    const telefone = value.replace(/\D/g, '')
    if (telefone.length <= 11) {
      return telefone.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3')
    }
    return value
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    e.stopPropagation()
    
    console.log('🚀 ========== FORMULÁRIO SUBMETIDO ==========')
    console.log('📋 Dados do formulário:', formData)
    console.log('📦 Plano selecionado:', plano)
    setLoading(true)

    // Validações
    if (!formData.nome.trim()) {
      console.log('Validação falhou: nome vazio')
      createNotification('Informe seu nome', 'warning')
      setLoading(false)
      return
    }

    if (!formData.email.trim() || !formData.email.includes('@')) {
      console.log('Validação falhou: email inválido')
      createNotification('Informe um email válido', 'warning')
      setLoading(false)
      return
    }

    if (formData.senha.length < 6) {
      console.log('Validação falhou: senha muito curta')
      createNotification('A senha deve ter pelo menos 6 caracteres', 'warning')
      setLoading(false)
      return
    }

    if (formData.senha !== formData.confirmarSenha) {
      console.log('Validação falhou: senhas não coincidem')
      createNotification('As senhas não coincidem', 'warning')
      setLoading(false)
      return
    }

    const whatsappLimpo = formData.whatsapp.replace(/\D/g, '')

    if (!whatsappLimpo || whatsappLimpo.length < 10) {
      console.log('Validação falhou: whatsapp inválido', whatsappLimpo)
      createNotification('Informe um WhatsApp válido (com DDD)', 'warning')
      setLoading(false)
      return
    }

    console.log('✅ Todas as validações passaram, criando conta...')

    try {
      console.log('📞 Chamando signUp com:', {
        email: formData.email,
        nome: formData.nome,
        whatsapp: whatsappLimpo,
        plano: plano
      })
      
      const result = await signUp(
        formData.email,
        formData.senha,
        formData.nome,
        '', // telefone removido - passar string vazia
        whatsappLimpo,
        plano
      )

      console.log('📥 Resultado do signUp recebido:', result)
      console.log('📥 Tipo do resultado:', typeof result)
      console.log('📥 Result.error:', result?.error)
      console.log('📥 Result.data:', result?.data)
      console.log('📥 Result.emailConfirmado:', result?.emailConfirmado)

      // Verificar se há erro
      if (result?.error) {
        console.error('❌ Erro ao criar conta:', result.error)
        
        // Mensagens de erro mais específicas
        let mensagemErro = result.error
        if (result.error.includes('already registered') || result.error.includes('já está cadastrado')) {
          mensagemErro = 'Este email já está cadastrado. Deseja fazer login?'
          // Opcional: adicionar botão para ir para login
        }
        
        createNotification(mensagemErro, 'warning')
        setLoading(false)
        return
      }

      // Verificar se a conta foi criada com sucesso
      if (result?.data || result?.emailConfirmado !== undefined) {
        console.log('✅ Conta criada com sucesso!')
        console.log('📧 Email cadastrado:', formData.email)
        console.log('📧 Email confirmado?', result?.emailConfirmado)
        console.log('🔔 Estado showModalConfirmacao ANTES:', showModalConfirmacao)
        
        // SEMPRE mostrar modal de confirmação se email não foi confirmado
        // Mesmo que já esteja confirmado, mostrar o modal para garantir
        setEmailCadastrado(formData.email)
        setShowModalConfirmacao(true)
        
        console.log('🔔 Estado showModalConfirmacao DEPOIS: true (deve ser true)')
        console.log('📧 Email cadastrado definido:', formData.email)
        
        createNotification('Conta criada! Verifique seu email e insira o código de confirmação.', 'success')
        setLoading(false)
        
        // Forçar re-render se necessário
        setTimeout(() => {
          console.log('🔄 Verificando se modal está visível após timeout...')
        }, 100)
      } else {
        console.error('❌ Resultado inesperado do signUp:', result)
        createNotification('Erro ao criar conta. Tente novamente.', 'warning')
        setLoading(false)
      }
    } catch (error: any) {
      console.error('❌ Erro inesperado no try/catch:', error)
      console.error('❌ Stack trace:', error?.stack)
      createNotification('Erro inesperado: ' + (error.message || 'Erro desconhecido'), 'warning')
      setLoading(false)
    }
  }

  const planosNomes = {
    teste: 'Teste Grátis',
    basico: 'Plano Básico',
    premium: 'Plano Premium',
  }

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center p-4">
      <AnimatedBackground />
      <div className="w-full max-w-md relative z-10">
        <Link
          href="/planos"
          className="inline-flex items-center gap-2 text-brand-clean/70 hover:text-brand-aqua transition-smooth mb-6"
        >
          <ArrowLeft size={20} />
          <span>Voltar para planos</span>
        </Link>

        <div className="bg-brand-royal/50 backdrop-blur-sm rounded-3xl p-8 border border-brand-aqua/20 shadow-2xl">
          <div className="text-center mb-8">
            <Image 
              src="/logo.png" 
              alt="PLENIPAY" 
              width={140}
              height={32}
              className="h-8 w-auto object-contain mx-auto mb-4"
              priority
            />
            <h1 className="text-3xl font-display font-bold text-brand-white mb-2">
              Criar Conta
            </h1>
            <p className="text-brand-clean/70">
              Plano selecionado: <span className="text-brand-aqua font-semibold">{planosNomes[plano]}</span>
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-brand-clean mb-2">
                Nome Completo *
              </label>
              <input
                type="text"
                required
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                className="w-full px-4 py-3 bg-brand-midnight/50 border border-brand-aqua/20 rounded-xl text-brand-white placeholder-brand-clean/40 focus:outline-none focus:border-brand-aqua transition-smooth"
                placeholder="Seu nome completo"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-brand-clean mb-2">
                Email *
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 bg-brand-midnight/50 border border-brand-aqua/20 rounded-xl text-brand-white placeholder-brand-clean/40 focus:outline-none focus:border-brand-aqua transition-smooth"
                placeholder="seu@email.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-brand-clean mb-2">
                Senha *
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={formData.senha}
                  onChange={(e) => setFormData({ ...formData, senha: e.target.value })}
                  className="w-full px-4 py-3 bg-brand-midnight/50 border border-brand-aqua/20 rounded-xl text-brand-white placeholder-brand-clean/40 focus:ring-2 focus:ring-brand-aqua focus:border-brand-aqua transition-smooth pr-12"
                  placeholder="Mínimo 6 caracteres"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-brand-clean/60 hover:text-brand-aqua transition-smooth"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-brand-clean mb-2">
                Confirmar Senha *
              </label>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={formData.confirmarSenha}
                onChange={(e) => setFormData({ ...formData, confirmarSenha: e.target.value })}
                className="w-full px-4 py-3 bg-brand-midnight/50 border border-brand-aqua/20 rounded-xl text-brand-white placeholder-brand-clean/40 focus:outline-none focus:border-brand-aqua transition-smooth"
                placeholder="Confirme sua senha"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-brand-clean mb-2">
                WhatsApp *
              </label>
              <input
                type="text"
                required
                value={formatarTelefone(formData.whatsapp)}
                onChange={(e) => {
                  const valorLimpo = e.target.value.replace(/\D/g, '')
                  setFormData({ ...formData, whatsapp: valorLimpo })
                }}
                maxLength={15}
                className="w-full px-4 py-3 bg-brand-midnight/50 border border-brand-aqua/20 rounded-xl text-brand-white placeholder-brand-clean/40 focus:outline-none focus:border-brand-aqua transition-smooth"
                placeholder="(00) 00000-0000"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              onClick={(e) => {
                console.log('Botão clicado!')
                // Não prevenir default aqui, deixar o form onSubmit fazer isso
              }}
              className="w-full px-6 py-4 bg-brand-aqua text-brand-midnight rounded-xl font-semibold hover:bg-brand-aqua/90 transition-smooth shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Criando conta...' : 'Criar Conta'}
            </button>

            <p className="text-center text-sm text-brand-clean/60">
              Ao criar uma conta, você concorda com nossos{' '}
              <Link href="#" className="text-brand-aqua hover:underline">Termos de Uso</Link>
              {' '}e{' '}
              <Link href="#" className="text-brand-aqua hover:underline">Política de Privacidade</Link>
            </p>

            <p className="text-center text-sm text-brand-clean/60">
              Já tem uma conta?{' '}
              <Link href="/login" className="text-brand-aqua hover:underline font-medium">
                Fazer login
              </Link>
            </p>
          </form>
        </div>
      </div>

      {/* Modal de Confirmação de Email - OBRIGATÓRIO */}
      {showModalConfirmacao && (emailCadastrado || formData.email) && (
        <ModalConfirmarEmail
          email={emailCadastrado || formData.email}
          obrigatorio={true}
          onConfirmado={() => {
            setShowModalConfirmacao(false)
            // Redirecionar para home após confirmação
            router.push('/home')
          }}
        />
      )}
    </div>
  )
}

