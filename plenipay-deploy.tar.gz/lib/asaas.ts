// lib/asaas.ts
// Utilitários para integração com Asaas

const ASAAS_API_URL = process.env.ASAAS_API_URL || 'https://www.asaas.com/api/v3'
const ASAAS_API_KEY = process.env.ASAAS_API_KEY!

// Verificar se a API key está configurada
if (!ASAAS_API_KEY) {
  console.error('⚠️ ASAAS_API_KEY não está configurada no .env.local')
}

// Helper para normalizar a API key (remove escape do $ se houver)
function getApiKey(): string {
  let apiKey = ASAAS_API_KEY.trim()
  if (apiKey.startsWith('\\$')) {
    apiKey = apiKey.substring(1) // Remove o escape
  }
  return apiKey
}

export interface AsaasCustomer {
  name: string
  email: string
  cpfCnpj?: string
  phone?: string
  externalReference?: string
  [key: string]: any // Permitir campos adicionais
}

export interface AsaasSubscription {
  customer: string // ID do customer
  billingType: 'PIX' | 'BOLETO' | 'CREDIT_CARD' | 'DEBIT_CARD'
  value: number
  nextDueDate: string // YYYY-MM-DD
  cycle: 'WEEKLY' | 'BIWEEKLY' | 'MONTHLY' | 'QUARTERLY' | 'SEMIANNUALLY' | 'YEARLY'
  description: string
  externalReference?: string
}

export interface AsaasResponse {
  id: string
  customer: string
  value: number
  nextDueDate: string
  cycle: string
  description: string
  invoiceUrl?: string
  [key: string]: any
}

/**
 * Criar um customer no Asaas
 */
export async function criarCustomerAsaas(customer: AsaasCustomer): Promise<AsaasResponse> {
  if (!ASAAS_API_KEY) {
    throw new Error('API Key do Asaas não configurada')
  }

  console.log('Criando customer no Asaas...', { 
    apiUrl: ASAAS_API_URL, 
    hasApiKey: !!ASAAS_API_KEY,
    apiKeyPrefix: ASAAS_API_KEY.substring(0, 10) + '...'
  })
  
  // Testar se a API key está funcionando primeiro
  const apiKey = getApiKey()
  console.log('🔑 API Key sendo usada:', {
    prefix: apiKey.substring(0, 15) + '...',
    length: apiKey.length,
    startsWithDollar: apiKey.startsWith('$'),
  })

  // Tentar primeiro com access_token, se falhar, tentar com Authorization
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  }
  
  // Asaas aceita access_token como header
  headers['access_token'] = apiKey
  
  console.log('📤 Headers sendo enviados:', {
    'Content-Type': headers['Content-Type'],
    'access_token': headers['access_token'].substring(0, 15) + '...',
  })

  const response = await fetch(`${ASAAS_API_URL}/customers`, {
    method: 'POST',
    headers: headers,
    body: JSON.stringify(customer),
  })
  
  console.log('📡 Resposta do Asaas:', {
    status: response.status,
    statusText: response.statusText,
    headers: Object.fromEntries(response.headers.entries()),
  })

  if (!response.ok) {
    const errorText = await response.text()
    let error
    try {
      error = JSON.parse(errorText)
    } catch {
      error = { message: errorText }
    }
    console.error('Erro ao criar customer:', {
      status: response.status,
      statusText: response.statusText,
      error: error
    })
    throw new Error(error.errors?.[0]?.description || error.message || 'Erro ao criar customer')
  }

  return response.json()
}

/**
 * Criar uma assinatura no Asaas
 */
export async function criarAssinaturaAsaas(subscription: AsaasSubscription): Promise<AsaasResponse> {
  const apiKey = getApiKey()
  console.log('📝 Criando assinatura no Asaas com API key:', apiKey.substring(0, 15) + '...')
  
  const response = await fetch(`${ASAAS_API_URL}/subscriptions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'access_token': apiKey,
    },
    body: JSON.stringify(subscription),
  })
  
  console.log('📡 Resposta da criação de assinatura:', {
    status: response.status,
    statusText: response.statusText,
  })

  if (!response.ok) {
    const error = await response.json()
    throw new Error(error.errors?.[0]?.description || error.message || 'Erro ao criar assinatura')
  }

  return response.json()
}

/**
 * Buscar uma assinatura no Asaas
 */
export async function buscarAssinaturaAsaas(subscriptionId: string): Promise<AsaasResponse> {
  const apiKey = getApiKey()
  const response = await fetch(`${ASAAS_API_URL}/subscriptions/${subscriptionId}`, {
    headers: {
      'access_token': apiKey,
    },
  })

  if (!response.ok) {
    throw new Error('Erro ao buscar assinatura')
  }

  return response.json()
}

/**
 * Cancelar uma assinatura no Asaas
 */
export async function cancelarAssinaturaAsaas(subscriptionId: string): Promise<AsaasResponse> {
  const apiKey = getApiKey()
  const response = await fetch(`${ASAAS_API_URL}/subscriptions/${subscriptionId}`, {
    method: 'DELETE',
    headers: {
      'access_token': apiKey,
    },
  })

  if (!response.ok) {
    throw new Error('Erro ao cancelar assinatura')
  }

  return response.json()
}

/**
 * Buscar um customer no Asaas
 */
export async function buscarCustomerAsaas(customerId: string): Promise<AsaasResponse> {
  const apiKey = getApiKey()
  const response = await fetch(`${ASAAS_API_URL}/customers/${customerId}`, {
    headers: {
      'access_token': apiKey,
    },
  })

  if (!response.ok) {
    throw new Error('Erro ao buscar customer')
  }

  return response.json()
}

/**
 * Atualizar um customer no Asaas
 */
export async function atualizarCustomerAsaas(customerId: string, customer: Partial<AsaasCustomer>): Promise<AsaasResponse> {
  const apiKey = getApiKey()
  console.log('🔄 Atualizando customer no Asaas:', {
    customerId,
    hasCpf: !!customer.cpfCnpj,
  })
  
  const response = await fetch(`${ASAAS_API_URL}/customers/${customerId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'access_token': apiKey,
    },
    body: JSON.stringify(customer),
  })

  console.log('📡 Resposta da atualização:', {
    status: response.status,
    statusText: response.statusText,
  })

  if (!response.ok) {
    const errorText = await response.text()
    let error
    try {
      error = JSON.parse(errorText)
    } catch {
      error = { message: errorText }
    }
    console.error('Erro ao atualizar customer:', {
      status: response.status,
      statusText: response.statusText,
      error: error
    })
    throw new Error(error.errors?.[0]?.description || error.message || 'Erro ao atualizar customer')
  }

  return response.json()
}

/**
 * Buscar pagamentos de uma assinatura
 */
export async function buscarPagamentosAssinatura(subscriptionId: string): Promise<any> {
  const apiKey = getApiKey()
  const response = await fetch(`${ASAAS_API_URL}/payments?subscription=${subscriptionId}`, {
    headers: {
      'access_token': apiKey,
    },
  })

  if (!response.ok) {
    throw new Error('Erro ao buscar pagamentos')
  }

  const data = await response.json()
  return data.data || []
}

/**
 * Buscar um pagamento específico
 */
export async function buscarPagamentoAsaas(paymentId: string): Promise<any> {
  const apiKey = getApiKey()
  const response = await fetch(`${ASAAS_API_URL}/payments/${paymentId}`, {
    headers: {
      'access_token': apiKey,
    },
  })

  if (!response.ok) {
    throw new Error('Erro ao buscar pagamento')
  }

  return response.json()
}



