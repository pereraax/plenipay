# 🔧 Corrigir .env.local - Erro do Supabase

## ⚠️ Problema Identificado

O erro mostra que as variáveis do **Supabase** não estão sendo encontradas. 
O arquivo `.env.local` precisa ter **TODAS** as variáveis necessárias.

---

## 📝 Solução: Verificar e Corrigir .env.local

### 1. Abra o arquivo `.env.local` na raiz do projeto

### 2. Verifique se tem TODAS estas variáveis:

```env
# ============================================
# CONFIGURAÇÕES SUPABASE (OBRIGATÓRIAS)
# ============================================
NEXT_PUBLIC_SUPABASE_URL=https://seu-projeto.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sua_chave_anon_aqui
SUPABASE_SERVICE_ROLE_KEY=sua_service_role_key_aqui

# ============================================
# CONFIGURAÇÕES ASAAS
# ============================================
ASAAS_ENVIRONMENT=sandbox
ASAAS_API_URL=https://sandbox.asaas.com/api/v3
ASAAS_API_KEY=$aact_YTU5YTE0M2M2N2I4MTIxNzlkOWYzNzQ0ZDQ1M2NhYw==

# ⚠️ IMPORTANTE: O webhook token deve ser um TOKEN, não uma URL!
# Gere um token seguro: openssl rand -base64 32
ASAAS_WEBHOOK_TOKEN=seu_token_seguro_aqui

# ============================================
# CONFIGURAÇÕES GERAIS
# ============================================
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

---

## 🔴 Erro no ASAAS_WEBHOOK_TOKEN

**Você colocou uma URL no `ASAAS_WEBHOOK_TOKEN`, mas deve ser um TOKEN!**

❌ **ERRADO:**
```env
ASAAS_WEBHOOK_TOKEN=https://SEU-PROJETO.supabase.co/functions/v1/asaas-webhook
```

✅ **CORRETO:**
```env
ASAAS_WEBHOOK_TOKEN=whk_asaas_2024_abc123xyz789!@#DEF456uvw012
```

**Como gerar um token:**
```bash
openssl rand -base64 32
```

Ou use um gerador online: https://www.random.org/strings/

---

## 📋 Checklist

Verifique se seu `.env.local` tem:

- [ ] `NEXT_PUBLIC_SUPABASE_URL` (com a URL do seu projeto Supabase)
- [ ] `NEXT_PUBLIC_SUPABASE_ANON_KEY` (com a chave anon do Supabase)
- [ ] `SUPABASE_SERVICE_ROLE_KEY` (opcional, mas recomendado)
- [ ] `ASAAS_ENVIRONMENT=sandbox`
- [ ] `ASAAS_API_URL=https://sandbox.asaas.com/api/v3`
- [ ] `ASAAS_API_KEY=$aact_YTU5YTE0M2M2N2I4MTIxNzlkOWYzNzQ0ZDQ1M2NhYw==`
- [ ] `ASAAS_WEBHOOK_TOKEN` (um TOKEN, não uma URL!)
- [ ] `NEXT_PUBLIC_SITE_URL=http://localhost:3000`

---

## 🚀 Após Corrigir

1. **Salve o arquivo** `.env.local`
2. **Pare o servidor** (Ctrl+C no terminal)
3. **Reinicie o servidor:**
   ```bash
   npm run dev
   ```

---

## 🔍 Onde Encontrar as Credenciais do Supabase?

1. Acesse: https://supabase.com/dashboard
2. Selecione seu projeto
3. Vá em **Settings** → **API**
4. Copie:
   - **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
   - **anon public key** → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **service_role key** → `SUPABASE_SERVICE_ROLE_KEY` (se necessário)

---

## ✅ Exemplo Completo Correto

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://frhxqgcqmxpjpnghsvoe.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZyaHhxZ2NxbXhwanBuZ2hzdm9lIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM2NTM3NTYsImV4cCI6MjA3OTIyOTc1Nn0.p1OxLRA5DKgvetuy-IbCfYClNSjrvK6fm43aZNX3T7I

# Asaas
ASAAS_ENVIRONMENT=sandbox
ASAAS_API_URL=https://sandbox.asaas.com/api/v3
ASAAS_API_KEY=$aact_YTU5YTE0M2M2N2I4MTIxNzlkOWYzNzQ0ZDQ1M2NhYw==
ASAAS_WEBHOOK_TOKEN=whk_asaas_2024_abc123xyz789!@#DEF456uvw012

# Geral
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```



