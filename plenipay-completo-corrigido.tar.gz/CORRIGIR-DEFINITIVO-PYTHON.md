# 🔧 Correção Definitiva com Python

## ⚠️ **Solução:**
Vamos usar Python para ler e reescrever os arquivos completamente, garantindo que não haja espaços.

---

## 📋 **EXECUTAR NO TERMINAL WEB:**

```bash
cd /var/www/plenipay

# Script Python completo
python3 << 'PYEOF'
import os
import re

def corrigir_arquivo(caminho):
    print(f"\n📝 Processando: {caminho}")
    
    try:
        # Ler arquivo
        with open(caminho, 'r', encoding='utf-8') as f:
            linhas = f.readlines()
        
        corrigido = False
        novas_linhas = []
        
        for num_linha, linha in enumerate(linhas, 1):
            linha_original = linha
            
            # Padrão 1: from ' @/ (espaço entre ' e @/)
            if re.search(r"from\s+['\"]\s+@/", linha):
                linha = re.sub(r"from\s+['\"]\s+@/", "from '@/", linha)
                print(f"  ✅ Linha {num_linha} corrigida (padrão 1)")
                print(f"     Antes: {linha_original.strip()}")
                print(f"     Depois: {linha.strip()}")
                corrigido = True
            
            # Padrão 2: from " @/ (aspas duplas)
            if re.search(r'from\s+"\s+@/', linha):
                linha = re.sub(r'from\s+"\s+@/', 'from "@/', linha)
                print(f"  ✅ Linha {num_linha} corrigida (padrão 2)")
                corrigido = True
            
            novas_linhas.append(linha)
        
        if corrigido:
            # Salvar arquivo
            with open(caminho, 'w', encoding='utf-8') as f:
                f.writelines(novas_linhas)
            print(f"  ✅ Arquivo salvo: {caminho}")
            return True
        else:
            print(f"  ℹ️ Nenhuma correção necessária: {caminho}")
            return False
            
    except Exception as e:
        print(f"  ❌ ERRO em {caminho}: {e}")
        return False

# Arquivos para corrigir
arquivos = [
    'app/admin/tutoriais/page.tsx',
    'app/admin/chat/page.tsx',
    'app/cadastro/page.tsx'
]

print("=" * 60)
print("🔧 CORREÇÃO DE IMPORTS COM ESPAÇOS")
print("=" * 60)

corrigidos = 0
for arquivo in arquivos:
    caminho_completo = os.path.join('.', arquivo)
    if os.path.exists(caminho_completo):
        if corrigir_arquivo(caminho_completo):
            corrigidos += 1
    else:
        print(f"⚠️ Arquivo não encontrado: {caminho_completo}")

print("\n" + "=" * 60)
print(f"✅ Total de arquivos corrigidos: {corrigidos}")
print("=" * 60)
PYEOF

# Verificar resultado
echo ""
echo "=== VERIFICAÇÃO FINAL ==="
grep -n "from.*@/" app/admin/tutoriais/page.tsx | head -5
grep -n "from.*@/" app/admin/chat/page.tsx | head -5
grep -n "from.*@/" app/cadastro/page.tsx | head -5

# Verificar se ainda há espaços
echo ""
echo "=== VERIFICANDO SE AINDA HÁ ESPAÇOS ==="
grep -n "from ' @/" app/admin/tutoriais/page.tsx app/admin/chat/page.tsx app/cadastro/page.tsx 2>/dev/null && echo "❌ AINDA HÁ ESPAÇOS!" || echo "✅ Nenhum espaço encontrado!"
```

---

## 📋 **DEPOIS: LIMPAR CACHE E BUILD**

```bash
cd /var/www/plenipay

# Limpar TUDO
rm -rf .next
rm -rf node_modules/.cache
rm -rf .swc

# Build
npm run build
```

---

**Execute o script Python acima no Terminal Web!** 🔧

