# 🔧 Corrigir Imports com Espaços Extras

## ⚠️ **Problema:**
Há espaços extras antes de `@/` nos imports, causando erros de build.

**Exemplo:** `' @/components/...'` (com espaço) → deve ser `'@/components/...'` (sem espaço)

---

## 📋 **SOLUÇÃO: CORRIGIR TODOS OS IMPORTS**

**No Terminal Web:**

```bash
cd /var/www/plenipay

# Corrigir espaços extras antes de @/ em TODOS os arquivos
find . -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
  ! -path "./node_modules/*" \
  ! -path "./.next/*" \
  -exec sed -i "s/from ' @\//from '@\//g" {} \;

# Corrigir também com aspas duplas
find . -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
  ! -path "./node_modules/*" \
  ! -path "./.next/*" \
  -exec sed -i 's/from " @\//from "@\//g' {} \;

# Verificar se corrigiu (deve mostrar os arquivos corrigidos)
grep -r "from ' @/" app/ components/ lib/ 2>/dev/null | head -5

# Se não mostrar nada, está corrigido!
```

---

## 📋 **VERIFICAR ARQUIVOS ESPECÍFICOS**

**No Terminal Web:**

```bash
cd /var/www/plenipay

# Verificar arquivos que deram erro
grep "from ' @/" app/admin/tutoriais/page.tsx 2>/dev/null
grep "from ' @/" app/cadastro/page.tsx 2>/dev/null
grep "from ' @/" app/admin/chat/page.tsx 2>/dev/null

# Se mostrar algo, ainda tem espaços. Se não mostrar nada, está OK!
```

---

## 📋 **TENTAR BUILD NOVAMENTE**

**No Terminal Web:**

```bash
cd /var/www/plenipay

# Limpar cache
rm -rf .next

# Build novamente
npm run build
```

**✅ Deve compilar agora!**

---

**Execute os comandos acima e me avise o resultado!** 🔧

