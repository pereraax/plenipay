# 🔧 Corrigir Espaços Diretamente no Servidor

## ⚠️ **Problema:**
Os arquivos no servidor ainda têm espaços antes de `@/` mesmo após tentativas anteriores.

**Arquivos problemáticos:**
- `app/admin/tutoriais/page.tsx` (linhas 4, 6, 7)
- `app/cadastro/page.tsx` (linha 5)

---

## 📋 **SOLUÇÃO: CORRIGIR ARQUIVO POR ARQUIVO COM SED ESPECÍFICO**

**No Terminal Web:**

```bash
cd /var/www/plenipay

# 1. Adicionar baseUrl ao tsconfig.json
sed -i '/"compilerOptions": {/a\    "baseUrl": ".",' tsconfig.json

# 2. Corrigir app/admin/tutoriais/page.tsx - linha 4
sed -i "4s/from ' @\//from '@/" app/admin/tutoriais/page.tsx

# 3. Corrigir app/admin/tutoriais/page.tsx - linha 6
sed -i "6s/from ' @\//from '@/" app/admin/tutoriais/page.tsx

# 4. Corrigir app/admin/tutoriais/page.tsx - linha 7
sed -i "7s/from ' @\//from '@/" app/admin/tutoriais/page.tsx

# 5. Corrigir app/cadastro/page.tsx - linha 5
sed -i "5s/from ' @\//from '@/" app/cadastro/page.tsx

# 6. Verificar se corrigiu
echo "=== Verificando app/admin/tutoriais/page.tsx ==="
sed -n '4p;6p;7p' app/admin/tutoriais/page.tsx | cat -A

echo "=== Verificando app/cadastro/page.tsx ==="
sed -n '5p' app/cadastro/page.tsx | cat -A

# 7. Verificar tsconfig.json
echo "=== Verificando tsconfig.json ==="
grep -A 2 "baseUrl" tsconfig.json
```

---

## 📋 **SE NÃO FUNCIONAR: USAR AWK**

**No Terminal Web:**

```bash
cd /var/www/plenipay

# Corrigir app/admin/tutoriais/page.tsx
awk '{gsub(/from '\'' @\//, "from '\''@\//"); print}' app/admin/tutoriais/page.tsx > /tmp/tutoriais_fixed.tsx && mv /tmp/tutoriais_fixed.tsx app/admin/tutoriais/page.tsx

# Corrigir app/cadastro/page.tsx
awk '{gsub(/from '\'' @\//, "from '\''@\//"); print}' app/cadastro/page.tsx > /tmp/cadastro_fixed.tsx && mv /tmp/cadastro_fixed.tsx app/cadastro/page.tsx

# Verificar
grep "from ' @/" app/admin/tutoriais/page.tsx app/cadastro/page.tsx
```

---

## 📋 **TENTAR BUILD NOVAMENTE**

**No Terminal Web:**

```bash
cd /var/www/plenipay

# Limpar cache
rm -rf .next

# Build
npm run build
```

---

**Execute os comandos do PASSO 1 primeiro!** 🔧

