# 🔧 Corrigir Imports no Servidor

## ❌ **Problema:**
Build falhou com erros de "Module not found" - provavelmente há espaços extras nos imports.

---

## 📋 **SOLUÇÃO: Corrigir Imports no Servidor**

**No Terminal Web, execute:**

```bash
cd /var/www/plenipay

# Corrigir espaços extras nos imports de todos os arquivos
find app -name "*.tsx" -o -name "*.ts" | xargs sed -i "s/from ' @\//from '@\//g"
find app -name "*.tsx" -o -name "*.ts" | xargs sed -i 's/from " @\//from "@\//g'
find components -name "*.tsx" -o -name "*.ts" | xargs sed -i "s/from ' @\//from '@\//g"
find components -name "*.tsx" -o -name "*.ts" | xargs sed -i 's/from " @\//from "@\//g'
find lib -name "*.tsx" -o -name "*.ts" | xargs sed -i "s/from ' @\//from '@\//g"
find lib -name "*.tsx" -o -name "*.ts" | xargs sed -i 's/from " @\//from "@\//g'

# Verificar se corrigiu
grep -r "from ' @/" app/ components/ lib/ 2>/dev/null | head -5
grep -r 'from " @/' app/ components/ lib/ 2>/dev/null | head -5
```

**✅ Se não mostrar nada, está correto!**

---

## 📋 **OU: Corrigir Arquivos Específicos**

**No Terminal Web:**

```bash
cd /var/www/plenipay

# Corrigir arquivos específicos mencionados nos erros
sed -i "s/from ' @\//from '@\//g" app/admin/tutoriais/page.tsx
sed -i 's/from " @\//from "@\//g' app/admin/tutoriais/page.tsx
sed -i "s/from ' @\//from '@\//g" app/admin/chat/page.tsx
sed -i 's/from " @\//from "@\//g' app/admin/chat/page.tsx
sed -i "s/from ' @\//from '@\//g" app/cadastro/page.tsx
sed -i 's/from " @\//from "@\//g' app/cadastro/page.tsx

# Verificar se corrigiu
grep "from ' @/" app/admin/tutoriais/page.tsx app/admin/chat/page.tsx app/cadastro/page.tsx 2>/dev/null
```

---

## 📋 **DEPOIS DE CORRIGIR: Tentar Build Novamente**

**No Terminal Web:**

```bash
cd /var/www/plenipay

# Limpar cache do Next.js
rm -rf .next

# Tentar build novamente
npm run build
```

**✅ Deve compilar com sucesso agora!**

---

## ⚠️ **SE AINDA DER ERRO:**

**Verifique se os arquivos existem:**

```bash
cd /var/www/plenipay

# Verificar se componentes existem
ls -la components/admin/AdminLayoutWrapper.tsx
ls -la components/NotificationBell.tsx
ls -la lib/supabase/client.ts
ls -la lib/auth.ts
```

**Se algum não existir, pode ser que não foi extraído corretamente. Nesse caso, reenvie o arquivo.**

---

**Execute os comandos de correção e me diga o resultado!** 🔧

