'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { User } from '@/lib/types'
import { obterUsuarios, criarUsuario, resetarTodosRegistros } from '@/lib/actions'
import { Users, Settings as SettingsIcon, Plus, Edit, Trash2, X, User as UserIcon, LogOut, Key, Mail, Eye, EyeOff, AlertTriangle, RotateCcw, MessageCircle, Phone, Crown } from 'lucide-react'
import { createNotification } from './NotificationBell'
import { atualizarSenha, reenviarEmailConfirmacao, signOut } from '@/lib/auth'
import { createClient } from '@/lib/supabase/client'
import ModalConfirmacao from './ModalConfirmacao'

interface ConfiguracoesViewProps {
  tabAtivo: string
}

export default function ConfiguracoesView({ tabAtivo: tabInicial }: ConfiguracoesViewProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [tabAtivo, setTabAtivo] = useState(tabInicial)
  const [usuarios, setUsuarios] = useState<User[]>([])
  const [loading, setLoading] = useState(false)
  const [showNovoUsuario, setShowNovoUsuario] = useState(false)
  const [novoUsuarioNome, setNovoUsuarioNome] = useState('')
  const [editandoUsuario, setEditandoUsuario] = useState<User | null>(null)
  
  // Estados para perfil
  const [userProfile, setUserProfile] = useState<any>(null)
  const [loadingProfile, setLoadingProfile] = useState(true)
  const [showRedefinirSenha, setShowRedefinirSenha] = useState(false)
  const [senhaAtual, setSenhaAtual] = useState('')
  const [novaSenha, setNovaSenha] = useState('')
  const [confirmarSenha, setConfirmarSenha] = useState('')
  const [showSenhaAtual, setShowSenhaAtual] = useState(false)
  const [showNovaSenha, setShowNovaSenha] = useState(false)
  const [showConfirmarSenha, setShowConfirmarSenha] = useState(false)
  const [loadingSenha, setLoadingSenha] = useState(false)
  const [showModalResetar, setShowModalResetar] = useState(false)
  const [loadingResetar, setLoadingResetar] = useState(false)
  const [confirmacaoResetar, setConfirmacaoResetar] = useState('')
  const [showModalLogout, setShowModalLogout] = useState(false)
  const [showModalExcluirUsuario, setShowModalExcluirUsuario] = useState(false)
  const [usuarioParaExcluir, setUsuarioParaExcluir] = useState<User | null>(null)
  const [cpf, setCpf] = useState('')
  const [editandoCpf, setEditandoCpf] = useState(false)
  const [loadingCpf, setLoadingCpf] = useState(false)

  useEffect(() => {
    if (searchParams.get('tab') === 'usuarios') {
      setTabAtivo('usuarios')
    } else if (searchParams.get('tab') === 'perfil') {
      setTabAtivo('perfil')
    }
    carregarUsuarios()
    carregarPerfil()
  }, [searchParams])
  
  const carregarPerfil = async () => {
    setLoadingProfile(true)
    try {
      const supabase = createClient()
      const { data: { user }, error: userError } = await supabase.auth.getUser()
      
      if (userError) {
        console.error('Erro ao buscar usuário:', userError)
        setLoadingProfile(false)
        return
      }
      
      if (user) {
        // Buscar perfil completo
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single()
        
        if (profileError && profileError.code !== 'PGRST116') {
          console.error('Erro ao buscar perfil:', profileError)
        }
        
        setUserProfile({
          ...user,
          profile: profile || null
        })
        
        // Carregar CPF se existir
        if (profile?.cpf) {
          setCpf(profile.cpf)
        }
      }
    } catch (error) {
      console.error('Erro ao carregar perfil:', error)
    } finally {
      setLoadingProfile(false)
    }
  }

  const carregarUsuarios = async () => {
    const result = await obterUsuarios()
    if (result.data) {
      setUsuarios(result.data)
    }
  }

  const handleCriarUsuario = async () => {
    if (!novoUsuarioNome.trim()) return

    setLoading(true)
    const formData = new FormData()
    formData.append('nome', novoUsuarioNome.trim())
    const result = await criarUsuario(formData)
    
    if (result.error) {
      createNotification('Erro ao criar usuário: ' + result.error, 'warning')
    } else {
      createNotification(`Usuário "${novoUsuarioNome.trim()}" criado com sucesso!`, 'success')
      // Recarregar usuários e atualizar a lista
      await carregarUsuarios()
      // Se não estava na aba de usuários, mudar para ela
      if (tabAtivo !== 'usuarios') {
        setTabAtivo('usuarios')
        router.push('/configuracoes?tab=usuarios')
      }
      setNovoUsuarioNome('')
      setShowNovoUsuario(false)
    }
    setLoading(false)
  }

  const handleRedefinirSenha = async () => {
    if (!senhaAtual || !novaSenha || !confirmarSenha) {
      createNotification('Preencha todos os campos', 'warning')
      return
    }

    if (novaSenha.length < 6) {
      createNotification('A nova senha deve ter pelo menos 6 caracteres', 'warning')
      return
    }

    if (novaSenha !== confirmarSenha) {
      createNotification('As senhas não coincidem', 'warning')
      return
    }

    setLoadingSenha(true)
    const result = await atualizarSenha(senhaAtual, novaSenha)
    
    if (result.error) {
      createNotification('Erro: ' + result.error, 'warning')
    } else {
      createNotification('Senha atualizada com sucesso!', 'success')
      setSenhaAtual('')
      setNovaSenha('')
      setConfirmarSenha('')
      setShowRedefinirSenha(false)
    }
    setLoadingSenha(false)
  }

  const handleReenviarEmail = async () => {
    if (!userProfile?.email) {
      createNotification('Email não encontrado', 'warning')
      return
    }

    setLoading(true)
    const result = await reenviarEmailConfirmacao()
    
    if (result.error) {
      createNotification('Erro: ' + result.error, 'warning')
    } else {
      createNotification('Email de confirmação reenviado! Verifique sua caixa de entrada.', 'success')
    }
    setLoading(false)
  }

  const handleLogout = async () => {
    try {
      const supabase = createClient()
      await supabase.auth.signOut()
      createNotification('Logout realizado com sucesso!', 'success')
      window.location.href = '/login'
    } catch (error) {
      console.error('Erro ao fazer logout:', error)
      createNotification('Erro ao fazer logout', 'warning')
    }
  }

  const handleResetarRegistros = async () => {
    if (confirmacaoResetar !== 'RESETAR') {
      createNotification('Digite "RESETAR" para confirmar', 'warning')
      return
    }

    setLoadingResetar(true)
    const result = await resetarTodosRegistros()
    
    if (result.error) {
      createNotification('Erro ao resetar registros: ' + result.error, 'warning')
    } else {
      createNotification('Todos os registros foram resetados com sucesso!', 'success')
      setShowModalResetar(false)
      setConfirmacaoResetar('')
      // Recarregar a página para atualizar os dados
      setTimeout(() => {
        window.location.reload()
      }, 1000)
    }
    setLoadingResetar(false)
  }

  // Aba "Usuários/Pessoas" sempre visível - cada conta vê apenas seus próprios usuários/pessoas
  const tabs = [
    { id: 'geral', label: 'Geral', icon: SettingsIcon },
    { id: 'usuarios', label: 'Usuários/Pessoas', icon: Users },
    { id: 'perfil', label: 'Perfil', icon: UserIcon },
  ]

  return (
    <div className="bg-brand-white dark:bg-brand-royal rounded-2xl shadow-lg border border-brand-clean dark:border-white/10 overflow-hidden">
      {/* Tabs */}
      <div className="border-b border-brand-clean">
        <div className="flex">
          {tabs.map((tab) => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setTabAtivo(tab.id)
                  router.push(`/configuracoes?tab=${tab.id}`)
                }}
                className={`flex items-center gap-2 px-6 py-4 font-medium transition-smooth ${
                  tabAtivo === tab.id
                    ? 'bg-brand-aqua/10 text-brand-aqua border-b-2 border-brand-aqua'
                    : 'text-brand-midnight dark:text-brand-clean/60 hover:text-brand-midnight dark:text-brand-clean hover:bg-brand-clean dark:bg-brand-royal/50'
                }`}
              >
                <Icon size={20} strokeWidth={2} />
                {tab.label}
              </button>
            )
          })}
        </div>
      </div>

      {/* Conteúdo */}
      <div className="p-6">
        {tabAtivo === 'geral' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-display font-semibold text-brand-midnight dark:text-brand-clean mb-4">
                Configurações Gerais
              </h2>
            </div>

            {/* Seção de Suporte no WhatsApp */}
            <div className="space-y-3 pb-6 border-b border-gray-200 dark:border-white/10">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg flex items-center justify-center">
                  {/* Logotipo oficial do WhatsApp */}
                  <svg 
                    width="20" 
                    height="20" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    xmlns="http://www.w3.org/2000/svg"
                    className="text-green-600 dark:text-green-400"
                  >
                    <path 
                      d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" 
                      fill="currentColor"
                    />
                  </svg>
                </div>
                <div className="flex-1">
                  <h3 className="text-base font-semibold text-brand-midnight dark:text-brand-clean mb-1">
                    Suporte no WhatsApp
                  </h3>
                  <p className="text-sm text-brand-midnight/70 dark:text-brand-clean/70 mb-3">
                    Precisa de ajuda? Entre em contato conosco pelo WhatsApp. Nossa equipe está pronta para ajudar você!
                  </p>
                  <a
                    href="https://wa.me/5511999999999?text=Olá!%20Preciso%20de%20ajuda%20com%20o%20PLENIPAY"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-3 py-1.5 bg-green-600 dark:bg-green-500 text-white rounded-lg hover:bg-green-700 dark:hover:bg-green-600 transition-smooth font-medium text-sm"
                  >
                    {/* Logotipo oficial do WhatsApp */}
                    <svg 
                      width="16" 
                      height="16" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      xmlns="http://www.w3.org/2000/svg"
                      className="text-white"
                    >
                      <path 
                        d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" 
                        fill="currentColor"
                      />
                    </svg>
                    Abrir WhatsApp
                  </a>
                </div>
              </div>
            </div>

            {/* Seção de Resetar Registros */}
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg">
                  <AlertTriangle className="text-red-600 dark:text-red-400" size={20} strokeWidth={2} />
                </div>
                <div className="flex-1">
                  <h3 className="text-base font-semibold text-brand-midnight dark:text-brand-clean mb-1">
                    Resetar Todos os Registros
                  </h3>
                  <p className="text-sm text-brand-midnight/70 dark:text-brand-clean/70 mb-3">
                    Esta ação irá <strong>permanentemente deletar</strong> todos os seus registros financeiros, incluindo entradas, saídas e dívidas. Esta ação não pode ser desfeita.
                  </p>
                  <button
                    onClick={() => setShowModalResetar(true)}
                    className="inline-flex items-center gap-2 px-3 py-1.5 bg-red-600 dark:bg-red-500 text-white rounded-lg hover:bg-red-700 dark:hover:bg-red-600 transition-smooth font-medium text-sm"
                  >
                    <RotateCcw size={16} strokeWidth={2} />
                    Resetar Todos os Registros
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {tabAtivo === 'perfil' && (
          <div className="space-y-6">
            {loadingProfile ? (
              <div className="text-center py-12">
                <p className="text-brand-midnight dark:text-brand-clean/60">Carregando perfil...</p>
              </div>
            ) : userProfile ? (
              <>
                {/* Informações do Perfil */}
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-display font-semibold text-brand-midnight dark:text-brand-clean mb-4">
                      Informações do Perfil
                    </h2>
                    
                    <div className="bg-brand-clean dark:bg-brand-royal/30 rounded-xl p-6 space-y-4 border border-brand-aqua/20">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 rounded-full bg-brand-aqua/20 flex items-center justify-center">
                          <span className="text-brand-aqua font-bold text-2xl">
                            {(userProfile.profile?.nome || userProfile.email || 'U').charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <p className="text-lg font-semibold text-brand-midnight dark:text-brand-clean">
                            {userProfile.profile?.nome || 'Usuário'}
                          </p>
                          <p className="text-sm text-brand-midnight dark:text-brand-clean/60">{userProfile.email}</p>
                        </div>
                      </div>

                      <div className="pt-4 border-t border-brand-midnight/10 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-brand-midnight dark:text-brand-clean/70">Email confirmado:</span>
                          <span className={`font-medium ${userProfile.email_confirmed_at ? 'text-green-600' : 'text-orange-600'}`}>
                            {userProfile.email_confirmed_at ? '✓ Confirmado' : '✗ Não confirmado'}
                          </span>
                        </div>
                        {userProfile.profile?.telefone && (
                          <div className="flex items-center justify-between">
                            <span className="text-brand-midnight dark:text-brand-clean/70">Telefone:</span>
                            <span className="text-brand-midnight dark:text-brand-clean">{userProfile.profile.telefone}</span>
                          </div>
                        )}
                        {userProfile.profile?.whatsapp && (
                          <div className="flex items-center justify-between">
                            <span className="text-brand-midnight dark:text-brand-clean/70">WhatsApp:</span>
                            <span className="text-brand-midnight dark:text-brand-clean">{userProfile.profile.whatsapp}</span>
                          </div>
                        )}
                        <div className="flex items-center justify-between">
                          <span className="text-brand-midnight dark:text-brand-clean/70">CPF:</span>
                          {editandoCpf ? (
                            <div className="flex items-center gap-2">
                              <input
                                type="text"
                                value={cpf}
                                onChange={(e) => {
                                  const value = e.target.value.replace(/\D/g, '')
                                  if (value.length <= 11) {
                                    const formatted = value.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4')
                                    setCpf(formatted)
                                  }
                                }}
                                placeholder="000.000.000-00"
                                maxLength={14}
                                className="px-3 py-1.5 bg-white dark:bg-brand-midnight border border-brand-aqua rounded-lg text-brand-midnight dark:text-brand-clean text-sm w-40 focus:outline-none focus:border-brand-aqua"
                              />
                              <button
                                onClick={async () => {
                                  setLoadingCpf(true)
                                  try {
                                    const supabase = createClient()
                                    const { data: { user } } = await supabase.auth.getUser()
                                    if (user) {
                                      const { error } = await supabase
                                        .from('profiles')
                                        .update({ cpf: cpf.replace(/\D/g, '') })
                                        .eq('id', user.id)
                                      
                                      if (error) {
                                        createNotification('Erro ao salvar CPF: ' + error.message, 'warning')
                                      } else {
                                        createNotification('CPF salvo com sucesso!', 'success')
                                        setEditandoCpf(false)
                                        carregarPerfil()
                                      }
                                    }
                                  } catch (error: any) {
                                    createNotification('Erro ao salvar CPF: ' + error.message, 'warning')
                                  } finally {
                                    setLoadingCpf(false)
                                  }
                                }}
                                disabled={loadingCpf || !cpf.replace(/\D/g, '').match(/^\d{11}$/)}
                                className="px-3 py-1.5 bg-brand-aqua text-white rounded-lg hover:bg-brand-aqua/90 transition-smooth text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                              >
                                {loadingCpf ? 'Salvando...' : 'Salvar'}
                              </button>
                              <button
                                onClick={() => {
                                  setEditandoCpf(false)
                                  setCpf(userProfile.profile?.cpf || '')
                                }}
                                className="px-3 py-1.5 bg-gray-200 dark:bg-brand-midnight text-brand-midnight dark:text-brand-clean rounded-lg hover:bg-gray-300 dark:hover:bg-brand-midnight/80 transition-smooth text-sm font-medium"
                              >
                                Cancelar
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2">
                              <span className="text-brand-midnight dark:text-brand-clean">
                                {cpf || 'Não informado'}
                              </span>
                              <button
                                onClick={() => setEditandoCpf(true)}
                                className="px-2 py-1 text-brand-aqua hover:bg-brand-aqua/10 rounded-lg text-xs font-medium transition-smooth"
                              >
                                {cpf ? 'Editar' : 'Adicionar'}
                              </button>
                            </div>
                          )}
                        </div>
                        {userProfile.profile?.plano && (
                          <div className="flex items-center justify-between">
                            <span className="text-brand-midnight dark:text-brand-clean/70">Plano:</span>
                            <div className="flex items-center gap-2">
                              <span className="px-3 py-1 bg-brand-aqua/20 text-brand-aqua rounded-lg font-medium capitalize">
                                {userProfile.profile.plano}
                              </span>
                              {userProfile.profile.plano_status && (
                                <span className={`px-2 py-1 text-xs rounded-lg font-medium ${
                                  userProfile.profile.plano_status === 'ativo' 
                                    ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                                    : 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400'
                                }`}>
                                  {userProfile.profile.plano_status}
                                </span>
                              )}
                              {userProfile.profile.plano === 'teste' && (
                                <button
                                  onClick={() => router.push('/upgrade')}
                                  className="px-4 py-1.5 bg-gradient-to-r from-brand-aqua to-blue-500 text-white rounded-lg font-semibold hover:from-brand-aqua/90 hover:to-blue-400 transition-smooth text-sm flex items-center gap-2 shadow-md hover:shadow-lg"
                                >
                                  <Crown size={16} />
                                  Fazer Upgrade
                                </button>
                              )}
                            </div>
                          </div>
                        )}
                        
                        {/* Botão de Simulação de Pagamento (apenas para testes) */}
                        {process.env.NODE_ENV === 'development' && (
                          <div className="pt-4 border-t border-brand-midnight/10">
                            <p className="text-xs text-brand-midnight/50 dark:text-brand-clean/50 mb-2">
                              🧪 Modo Desenvolvimento
                            </p>
                            <div className="flex gap-2">
                              <button
                                onClick={async () => {
                                  try {
                                    const response = await fetch('/api/pagamento/simular', {
                                      method: 'POST',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify({ plano: 'basico' }),
                                    })
                                    const data = await response.json()
                                    if (response.ok) {
                                      createNotification('Plano Básico simulado com sucesso!', 'success')
                                      setTimeout(() => window.location.reload(), 1000)
                                    } else {
                                      createNotification('Erro: ' + data.error, 'warning')
                                    }
                                  } catch (error: any) {
                                    createNotification('Erro ao simular pagamento', 'warning')
                                  }
                                }}
                                className="px-3 py-1.5 bg-blue-500 text-white rounded-lg text-xs font-medium hover:bg-blue-600 transition-smooth"
                              >
                                Simular Básico
                              </button>
                              <button
                                onClick={async () => {
                                  try {
                                    const response = await fetch('/api/pagamento/simular', {
                                      method: 'POST',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify({ plano: 'premium' }),
                                    })
                                    const data = await response.json()
                                    if (response.ok) {
                                      createNotification('Plano Premium simulado com sucesso!', 'success')
                                      setTimeout(() => window.location.reload(), 1000)
                                    } else {
                                      createNotification('Erro: ' + data.error, 'warning')
                                    }
                                  } catch (error: any) {
                                    createNotification('Erro ao simular pagamento', 'warning')
                                  }
                                }}
                                className="px-3 py-1.5 bg-purple-500 text-white rounded-lg text-xs font-medium hover:bg-purple-600 transition-smooth"
                              >
                                Simular Premium
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Redefinir Senha */}
                  <div>
                    <h2 className="text-xl font-display font-semibold text-brand-midnight dark:text-brand-clean mb-4">
                      Segurança
                    </h2>
                    
                    <div className="space-y-4">
                      {!showRedefinirSenha ? (
                        <div className="flex justify-start">
                          <button
                            onClick={() => setShowRedefinirSenha(true)}
                            className="px-3 py-1.5 text-brand-aqua hover:text-brand-aqua/80 hover:bg-brand-aqua/10 rounded-lg font-medium transition-smooth flex items-center gap-2 text-sm"
                          >
                            <Key size={16} />
                            Redefinir Senha
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-medium text-brand-midnight dark:text-brand-clean mb-2">
                              Senha Atual
                            </label>
                            <div className="relative">
                              <input
                                type={showSenhaAtual ? 'text' : 'password'}
                                value={senhaAtual}
                                onChange={(e) => setSenhaAtual(e.target.value)}
                                className="w-full px-4 py-3 bg-white dark:bg-brand-midnight border border-gray-300 rounded-xl focus:outline-none focus:border-brand-aqua transition-smooth pr-12 text-brand-midnight dark:text-brand-clean"
                                placeholder="Digite sua senha atual"
                              />
                              <button
                                type="button"
                                onClick={() => setShowSenhaAtual(!showSenhaAtual)}
                                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-brand-midnight dark:text-brand-clean/60 hover:text-brand-aqua"
                              >
                                {showSenhaAtual ? <EyeOff size={20} /> : <Eye size={20} />}
                              </button>
                            </div>
                          </div>

                          <div>
                            <label className="block text-sm font-medium text-brand-midnight dark:text-brand-clean mb-2">
                              Nova Senha
                            </label>
                            <div className="relative">
                              <input
                                type={showNovaSenha ? 'text' : 'password'}
                                value={novaSenha}
                                onChange={(e) => setNovaSenha(e.target.value)}
                                className="w-full px-4 py-3 bg-white dark:bg-brand-midnight border border-gray-300 rounded-xl focus:outline-none focus:border-brand-aqua transition-smooth pr-12 text-brand-midnight dark:text-brand-clean"
                                placeholder="Digite a nova senha"
                              />
                              <button
                                type="button"
                                onClick={() => setShowNovaSenha(!showNovaSenha)}
                                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-brand-midnight dark:text-brand-clean/60 hover:text-brand-aqua"
                              >
                                {showNovaSenha ? <EyeOff size={20} /> : <Eye size={20} />}
                              </button>
                            </div>
                          </div>

                          <div>
                            <label className="block text-sm font-medium text-brand-midnight dark:text-brand-clean mb-2">
                              Confirmar Nova Senha
                            </label>
                            <div className="relative">
                              <input
                                type={showConfirmarSenha ? 'text' : 'password'}
                                value={confirmarSenha}
                                onChange={(e) => setConfirmarSenha(e.target.value)}
                                className="w-full px-4 py-3 bg-white dark:bg-brand-midnight border border-gray-300 rounded-xl focus:outline-none focus:border-brand-aqua transition-smooth pr-12 text-brand-midnight dark:text-brand-clean"
                                placeholder="Confirme a nova senha"
                              />
                              <button
                                type="button"
                                onClick={() => setShowConfirmarSenha(!showConfirmarSenha)}
                                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-brand-midnight dark:text-brand-clean/60 hover:text-brand-aqua"
                              >
                                {showConfirmarSenha ? <EyeOff size={20} /> : <Eye size={20} />}
                              </button>
                            </div>
                          </div>

                          <div className="flex gap-2">
                            <button
                              onClick={handleRedefinirSenha}
                              disabled={loadingSenha}
                              className="flex-1 px-4 py-3 bg-brand-aqua text-brand-midnight dark:text-brand-clean rounded-xl font-semibold hover:bg-brand-aqua/90 shadow-md transition-smooth disabled:opacity-50"
                            >
                              {loadingSenha ? 'Atualizando...' : 'Atualizar Senha'}
                            </button>
                            <button
                              onClick={() => {
                                setShowRedefinirSenha(false)
                                setSenhaAtual('')
                                setNovaSenha('')
                                setConfirmarSenha('')
                              }}
                              className="px-4 py-3 bg-brand-clean dark:bg-brand-royal text-brand-midnight dark:text-brand-clean rounded-xl font-semibold hover:bg-brand-clean dark:bg-brand-royal/80 transition-smooth"
                            >
                              Cancelar
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Confirmar Email */}
                  {!userProfile.email_confirmed_at && (
                    <div>
                      <h2 className="text-xl font-display font-semibold text-brand-midnight dark:text-brand-clean mb-4">
                        Confirmação de Email
                      </h2>
                      
                      <div className="bg-orange-50 border border-orange-200 rounded-xl p-6 space-y-4">
                        <div className="flex items-start gap-3">
                          <Mail className="text-orange-600 mt-1" size={24} />
                          <div className="flex-1">
                            <p className="text-orange-800 font-medium mb-2">
                              Seu email ainda não foi confirmado
                            </p>
                            <p className="text-orange-700 text-sm mb-4">
                              Verifique sua caixa de entrada e spam. Se não recebeu o email, clique no botão abaixo para reenviar.
                            </p>
                            <button
                              onClick={handleReenviarEmail}
                              disabled={loading}
                              className="px-4 py-2 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-700 shadow-md transition-smooth disabled:opacity-50 flex items-center gap-2"
                            >
                              <Mail size={18} />
                              {loading ? 'Enviando...' : 'Reenviar Email de Confirmação'}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Logout */}
                  <div>
                    <h2 className="text-xl font-display font-semibold text-brand-midnight dark:text-brand-clean mb-4">
                      Sessão
                    </h2>
                    
                    <div className="flex justify-start">
                      <button
                        onClick={() => setShowModalLogout(true)}
                        className="px-3 py-1.5 text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg font-medium transition-smooth flex items-center gap-2 text-sm"
                      >
                        <LogOut size={16} />
                        Sair da Conta
                      </button>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center py-12">
                <p className="text-brand-midnight dark:text-brand-clean/60">Erro ao carregar perfil</p>
              </div>
            )}
          </div>
        )}

        {tabAtivo === 'usuarios' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-display font-semibold text-brand-midnight dark:text-brand-clean">
                Gerenciar Usuários/Pessoas
              </h2>
              <button
                onClick={() => setShowNovoUsuario(!showNovoUsuario)}
                className="px-4 py-2 bg-brand-aqua/90 text-brand-midnight dark:text-brand-clean rounded-xl font-semibold hover:bg-brand-aqua shadow-md hover:shadow-lg backdrop-blur-md transition-smooth flex items-center gap-2"
              >
                <Plus size={20} strokeWidth={2} />
                Novo Usuário
              </button>
            </div>

            {/* Formulário novo usuário */}
            {showNovoUsuario && (
              <div className="p-4 bg-brand-clean dark:bg-brand-royal/30 rounded-xl border border-gray-200 backdrop-blur-sm">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={novoUsuarioNome}
                    onChange={(e) => setNovoUsuarioNome(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleCriarUsuario()}
                    placeholder="Nome do novo usuário"
                    className="flex-1 px-4 py-2 bg-white dark:bg-brand-midnight border border-gray-300 rounded-lg text-brand-midnight dark:text-brand-clean placeholder-gray-400 focus:outline-none focus:border-gray-400 transition-smooth"
                  />
                  <button
                    onClick={handleCriarUsuario}
                    disabled={loading || !novoUsuarioNome.trim()}
                    className="px-6 py-2 bg-brand-aqua text-white rounded-lg hover:bg-blue-600 shadow-md transition-smooth disabled:opacity-50 disabled:cursor-not-allowed font-medium"
                  >
                    {loading ? 'Criando...' : 'Criar'}
                  </button>
                  <button
                    onClick={() => {
                      setShowNovoUsuario(false)
                      setNovoUsuarioNome('')
                    }}
                    className="px-4 py-2 bg-brand-clean dark:bg-brand-royal text-brand-midnight dark:text-brand-clean rounded-lg hover:bg-brand-clean dark:bg-brand-royal/80 transition-smooth"
                  >
                    <X size={18} />
                  </button>
                </div>
              </div>
            )}

            {/* Lista de usuários */}
            <div className="space-y-3">
              {usuarios.length === 0 ? (
                <div className="text-center py-12 bg-brand-clean dark:bg-brand-royal/30 rounded-xl">
                  <p className="text-brand-midnight dark:text-brand-clean/60">
                    Nenhum usuário cadastrado ainda
                  </p>
                </div>
              ) : (
                usuarios.map((user) => (
                  <div
                    key={user.id}
                    className="p-4 bg-white dark:bg-brand-midnight/60 border border-gray-200 rounded-xl hover:bg-brand-clean dark:bg-brand-royal/50 transition-smooth backdrop-blur-sm flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-brand-aqua/20 flex items-center justify-center">
                        <span className="text-brand-aqua font-bold text-xl">
                          {user.nome.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-brand-midnight dark:text-brand-clean">{user.nome}</p>
                        <p className="text-xs text-brand-midnight dark:text-brand-clean/50">
                          Criado em {new Date(user.created_at).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setEditandoUsuario(user)}
                        className="p-2 text-brand-aqua hover:bg-brand-aqua/10 rounded-lg transition-smooth"
                        title="Editar"
                      >
                        <Edit size={18} strokeWidth={2} />
                      </button>
                      <button
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-smooth"
                        title="Excluir"
                        onClick={() => {
                          setUsuarioParaExcluir(user)
                          setShowModalExcluirUsuario(true)
                        }}
                      >
                        <Trash2 size={18} strokeWidth={2} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Modal de Confirmação para Resetar Registros */}
      {showModalResetar && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 glass-backdrop">
          <div className="bg-brand-white rounded-2xl shadow-2xl max-w-md w-full p-6 animate-slide-up border border-brand-clean">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-red-100 rounded-xl">
                <AlertTriangle className="text-red-600" size={24} strokeWidth={2} />
              </div>
              <h3 className="text-xl font-display font-bold text-brand-midnight dark:text-brand-clean">
                Confirmar Reset de Registros
              </h3>
            </div>

            <div className="space-y-4 mb-6">
              <p className="text-brand-midnight dark:text-brand-clean/80">
                Você está prestes a <strong className="text-red-600">permanentemente deletar</strong> todos os seus registros financeiros.
              </p>
              <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                <p className="text-sm text-red-800 font-medium">
                  ⚠️ Esta ação não pode ser desfeita!
                </p>
                <ul className="mt-2 text-sm text-red-700 space-y-1 list-disc list-inside">
                  <li>Todos os registros de entrada serão deletados</li>
                  <li>Todos os registros de saída serão deletados</li>
                  <li>Todas as dívidas serão deletadas</li>
                  <li>Todos os empréstimos serão deletados</li>
                </ul>
              </div>
              <div>
                <label className="block text-sm font-medium text-brand-midnight dark:text-brand-clean mb-2">
                  Digite <strong className="text-red-600">RESETAR</strong> para confirmar:
                </label>
                <input
                  type="text"
                  value={confirmacaoResetar}
                  onChange={(e) => setConfirmacaoResetar(e.target.value)}
                  placeholder="Digite RESETAR"
                  className="w-full px-4 py-2 border border-gray-300 rounded-xl focus:outline-none focus:border-red-500 transition-smooth text-brand-midnight dark:text-brand-clean bg-white dark:bg-brand-midnight"
                  autoFocus
                />
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowModalResetar(false)
                  setConfirmacaoResetar('')
                }}
                disabled={loadingResetar}
                className="flex-1 px-4 py-2 bg-brand-clean dark:bg-brand-royal text-brand-midnight dark:text-brand-clean rounded-xl hover:bg-brand-clean dark:bg-brand-royal/80 transition-smooth font-medium disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                onClick={handleResetarRegistros}
                disabled={loadingResetar || confirmacaoResetar !== 'RESETAR'}
                className="flex-1 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-smooth font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loadingResetar ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Resetando...</span>
                  </>
                ) : (
                  <>
                    <RotateCcw size={18} strokeWidth={2} />
                    <span>Confirmar Reset</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Confirmação para Logout */}
      {showModalLogout && (
        <ModalConfirmacao
          titulo="Confirmar Saída"
          mensagem="Tem certeza que deseja sair da sua conta?"
          onConfirmar={handleLogout}
          onCancelar={() => setShowModalLogout(false)}
          textoConfirmar="Sair"
          tipo="warning"
        />
      )}

      {/* Modal de Confirmação para Excluir Usuário */}
      {showModalExcluirUsuario && usuarioParaExcluir && (
        <ModalConfirmacao
          titulo="Excluir Usuário"
          mensagem={`Tem certeza que deseja excluir "${usuarioParaExcluir.nome}"? Esta ação não pode ser desfeita.`}
          onConfirmar={() => {
            createNotification('Funcionalidade de exclusão em desenvolvimento', 'info')
            setShowModalExcluirUsuario(false)
            setUsuarioParaExcluir(null)
          }}
          onCancelar={() => {
            setShowModalExcluirUsuario(false)
            setUsuarioParaExcluir(null)
          }}
          textoConfirmar="Excluir"
          tipo="danger"
        />
      )}
    </div>
  )
}

