'use client'

import Image from 'next/image'
import { useState } from 'react'

export default function Logo() {
  const [imageError, setImageError] = useState(false)

  if (imageError) {
    // Fallback: mostrar texto do logo se a imagem não carregar
    return (
      <div className="flex items-center justify-center py-2 px-3 w-full">
        <div className="text-2xl font-bold text-brand-aqua">
          PLENIPAY
        </div>
      </div>
    )
  }

  return (
    <div className="flex items-center justify-center py-2 px-3 w-full">
      <Image 
        src="/logo.png" 
        alt="PLENIPAY" 
        width={240}
        height={60}
        className="w-full h-auto object-contain"
        style={{ 
          maxHeight: '90px',
          width: '100%',
          objectFit: 'contain',
          display: 'block'
        }}
        priority
        unoptimized
        onError={() => setImageError(true)}
      />
    </div>
  )
}

