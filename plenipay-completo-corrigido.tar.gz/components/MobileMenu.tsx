'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { 
  Home, 
  FileText, 
  CreditCard, 
  Calendar, 
  BarChart3,
  Settings,
  Menu,
  X,
  PiggyBank,
  PlayCircle
} from 'lucide-react'
import Logo from './Logo'

const menuItems = [
  { href: '/home', label: 'Home', icon: Home },
  { href: '/registros', label: 'Registros', icon: FileText },
  { href: '/dividas', label: 'Dívidas', icon: CreditCard },
  { href: '/minhas-metas', label: 'Minhas Metas', icon: PiggyBank },
  { href: '/calendario', label: 'Calendário', icon: Calendar },
  { href: '/dashboard', label: 'Dashboard', icon: BarChart3 },
  { href: '/tutoriais', label: 'Tutoriais', icon: PlayCircle },
  { href: '/configuracoes', label: 'Configurações', icon: Settings },
]

export default function MobileMenu() {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed top-4 left-4 z-50 p-2 bg-brand-white dark:bg-brand-royal rounded-xl shadow-lg lg:hidden transition-smooth border border-gray-200 dark:border-white/10"
      >
        {isOpen ? <X size={24} className="text-brand-midnight dark:text-brand-clean" /> : <Menu size={24} className="text-brand-midnight dark:text-brand-clean" />}
      </button>

      {isOpen && (
        <>
          <div
            className="fixed inset-0 bg-brand-midnight/50 z-40 lg:hidden"
            onClick={() => setIsOpen(false)}
          />
          <aside className="fixed left-0 top-0 h-screen w-64 bg-brand-royal border-r border-brand-midnight shadow-lg z-40 lg:hidden">
            <div className="p-6">
              <div className="mb-8">
                <Logo />
              </div>
              <nav className="space-y-2">
                {menuItems.map((item) => {
                  const Icon = item.icon
                  const isActive = pathname === item.href || 
                    (item.href !== '/home' && pathname?.startsWith(item.href))
                  
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setIsOpen(false)}
                      className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-smooth ${
                        isActive
                          ? 'bg-brand-aqua text-brand-midnight shadow-lg'
                          : 'text-brand-clean hover:bg-brand-midnight/50 hover:text-brand-aqua'
                      }`}
                    >
                      <Icon size={20} strokeWidth={2} />
                      <span className="font-medium">{item.label}</span>
                    </Link>
                  )
                })}
              </nav>
            </div>
          </aside>
        </>
      )}
    </>
  )
}

