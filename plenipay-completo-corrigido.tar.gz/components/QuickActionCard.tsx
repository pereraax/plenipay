'use client'

import { useState, useEffect } from 'react'
import { Plus, FileText, DollarSign, Hand, CreditCard } from 'lucide-react'
import ModalEditarRegistro from './ModalEditarRegistro'
import ModalSalario from './ModalSalario'
import ModalEmprestimo from './ModalEmprestimo'
import ModalDivida from './ModalDivida'
import UpgradeModal from './UpgradeModal'
import { obterPlanoUsuario } from '@/lib/plano'

interface QuickActionCardProps {
  title: string
  description: string
  buttonText: string
  iconName: 'FileText' | 'DollarSign' | 'Hand' | 'CreditCard'
  type: 'registro' | 'salario' | 'emprestimo' | 'divida'
}

export default function QuickActionCard({
  title,
  description,
  buttonText,
  iconName,
  type
}: QuickActionCardProps) {
  const [showModal, setShowModal] = useState(false)
  const [showUpgradeModal, setShowUpgradeModal] = useState(false)
  const [planoAtual, setPlanoAtual] = useState<'teste' | 'basico' | 'premium'>('teste')

  useEffect(() => {
    async function carregarPlano() {
      const plano = await obterPlanoUsuario()
      setPlanoAtual(plano)
    }
    carregarPlano()
  }, [])

  const iconMap = {
    FileText: FileText,
    DollarSign: DollarSign,
    Hand: Hand,
    CreditCard: CreditCard,
  }

  const Icon = iconMap[iconName]

  const handleClick = () => {
    // Verificar se precisa de plano específico
    if (type === 'divida' && planoAtual === 'teste') {
      setShowUpgradeModal(true)
      return
    }
    if (type === 'salario' && planoAtual === 'teste') {
      setShowUpgradeModal(true)
      return
    }
    if (type === 'emprestimo' && planoAtual !== 'premium') {
      setShowUpgradeModal(true)
      return
    }
    
    setShowModal(true)
  }

  const planoNecessario = 
    type === 'emprestimo' ? 'premium' :
    type === 'divida' || type === 'salario' ? 'basico' :
    'teste'

  return (
    <>
      <div className="bg-brand-white dark:bg-brand-royal rounded-2xl p-6 shadow-lg border border-brand-clean dark:border-white/10 hover:shadow-xl transition-smooth animate-slide-up">
        <div className="flex items-start gap-4 mb-4">
          <div className="p-3 bg-brand-aqua/10 dark:bg-brand-aqua/20 rounded-xl">
            <Icon size={28} className="text-brand-aqua dark:text-brand-aqua" strokeWidth={2} />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-display font-bold text-brand-midnight dark:text-brand-clean mb-2">
              {title}
            </h3>
            <p className="text-sm text-brand-midnight/70 dark:text-brand-clean/70 leading-relaxed">
              {description}
            </p>
          </div>
        </div>
        <button
          onClick={handleClick}
          className="w-full px-6 py-3 bg-brand-aqua dark:bg-brand-aqua text-brand-midnight dark:text-brand-midnight rounded-xl font-semibold hover:bg-brand-aqua/90 dark:hover:bg-brand-aqua/80 transition-smooth shadow-md hover:shadow-lg flex items-center justify-center gap-2"
        >
          <Plus size={20} strokeWidth={2.5} />
          {buttonText}
        </button>
      </div>

      {showModal && type === 'registro' && (
        <ModalEditarRegistro
          registro={null}
          onClose={() => setShowModal(false)}
        />
      )}

      {showModal && type === 'salario' && (
        <ModalSalario
          onClose={() => setShowModal(false)}
        />
      )}

      {showModal && type === 'emprestimo' && (
        <ModalEmprestimo
          onClose={() => setShowModal(false)}
        />
      )}

      {showModal && type === 'divida' && (
        <ModalDivida
          onClose={() => setShowModal(false)}
        />
      )}

      {showUpgradeModal && (
        <UpgradeModal
          isOpen={showUpgradeModal}
          onClose={() => setShowUpgradeModal(false)}
          feature={title}
          planoNecessario={planoNecessario as 'basico' | 'premium'}
          planoAtual={planoAtual}
        />
      )}
    </>
  )
}

