import Sidebar from '@/components/Sidebar'
import MobileMenu from '@/components/MobileMenu'
import CalendarioView from '@/components/CalendarioView'
import PlanoGuard from '@/components/PlanoGuard'
import { obterRegistros, obterUsuarios } from '@/lib/actions'
import { Suspense } from 'react'

// Otimizar: cache de 30 segundos (dados mudam mais frequentemente)
export const revalidate = 30

// Middleware já verifica autenticação

async function CalendarioContent() {
  const [registrosResult, usuariosResult] = await Promise.all([
    obterRegistros(),
    obterUsuarios()
  ])
  return <CalendarioView registros={registrosResult.data || []} usuarios={usuariosResult.data || []} />
}

export default async function CalendarioPage() {

  return (
    <div className="min-h-screen bg-brand-clean dark:bg-brand-midnight">
      <MobileMenu />
      <Sidebar />
      <main className="lg:ml-64 p-4 lg:p-8 dark:bg-brand-midnight">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-display font-bold text-brand-midnight dark:text-brand-clean mb-8">
            Calendário
          </h1>
          <PlanoGuard feature="Calendário Financeiro" planoNecessario="basico">
            <Suspense fallback={<div className="text-center py-12 text-brand-midnight/60 dark:text-brand-clean/60">Carregando...</div>}>
              <CalendarioContent />
            </Suspense>
          </PlanoGuard>
        </div>
      </main>
    </div>
  )
}

