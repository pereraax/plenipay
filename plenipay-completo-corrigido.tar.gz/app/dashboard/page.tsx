import Sidebar from '@/components/Sidebar'
import MobileMenu from '@/components/MobileMenu'
import DashboardView from '@/components/DashboardView'
import { obterRegistros, obterEstatisticas } from '@/lib/actions'
import { Suspense } from 'react'

// Otimizar: cache de 30 segundos (dados mudam mais frequentemente)
export const revalidate = 30

// Middleware já verifica autenticação

async function DashboardContent() {
  const [registrosResult, statsResult] = await Promise.all([
    obterRegistros(),
    obterEstatisticas()
  ])
  
  // Filtrar apenas entradas e saídas, excluindo dívidas
  // Dívidas têm seção própria e só assinantes têm acesso
  const registrosFiltrados = (registrosResult.data || []).filter(
    (reg) => reg.tipo === 'entrada' || reg.tipo === 'saida'
  )
  
  return (
    <DashboardView
      registros={registrosFiltrados}
      estatisticas={statsResult}
    />
  )
}

export default async function DashboardPage() {

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-brand-midnight">
      <MobileMenu />
      <Sidebar />
      <main className="lg:ml-64 p-4 lg:p-8 dark:bg-brand-midnight">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-brand-clean mb-8">
            Dashboard / Relatórios
          </h1>
          <Suspense fallback={<div className="text-center py-12 text-gray-600 dark:text-brand-clean/60">Carregando...</div>}>
            <DashboardContent />
          </Suspense>
        </div>
      </main>
    </div>
  )
}

