import Sidebar from '@/components/Sidebar'
import MobileMenu from '@/components/MobileMenu'
import ConfiguracoesView from '@/components/ConfiguracoesView'

// Otimizar: cache de 60 segundos (configurações mudam pouco)
export const revalidate = 60

// Middleware já verifica autenticação, não precisa verificar novamente aqui

export default async function ConfiguracoesPage({
  searchParams,
}: {
  searchParams: { tab?: string }
}) {

  return (
    <div className="min-h-screen bg-brand-clean dark:bg-brand-midnight">
      <MobileMenu />
      <Sidebar />
      <main className="lg:ml-64 p-4 lg:p-8 dark:bg-brand-midnight">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-display font-bold text-brand-midnight dark:text-brand-clean mb-8">
            Configurações
          </h1>
          <ConfiguracoesView tabAtivo={searchParams.tab || 'geral'} />
        </div>
      </main>
    </div>
  )
}
