import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json(
        { error: 'Não autenticado' },
        { status: 401 }
      )
    }

    // TODO: Verificar se o usuário é admin/suporte
    // Por enquanto, permitir qualquer usuário autenticado finalizar conversas

    const { user_id } = await request.json()

    if (!user_id) {
      return NextResponse.json(
        { error: 'user_id é obrigatório' },
        { status: 400 }
      )
    }

    // Verificar se a conversa já existe
    const { data: existingConversation } = await supabase
      .from('chat_conversations')
      .select('*')
      .eq('user_id', user_id)
      .single()

    if (existingConversation) {
      // Atualizar conversa existente
      const { data, error } = await supabase
        .from('chat_conversations')
        .update({
          is_closed: true,
          closed_at: new Date().toISOString(),
          closed_by: user.id,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', user_id)
        .select()
        .single()

      if (error) {
        console.error('Erro ao finalizar conversa:', error)
        return NextResponse.json(
          { error: 'Erro ao finalizar conversa' },
          { status: 500 }
        )
      }

      return NextResponse.json({ success: true, data })
    } else {
      // Criar nova entrada de conversa finalizada
      const { data, error } = await supabase
        .from('chat_conversations')
        .insert([
          {
            user_id: user_id,
            is_closed: true,
            closed_at: new Date().toISOString(),
            closed_by: user.id
          }
        ])
        .select()
        .single()

      if (error) {
        console.error('Erro ao criar conversa finalizada:', error)
        return NextResponse.json(
          { error: 'Erro ao finalizar conversa' },
          { status: 500 }
        )
      }

      return NextResponse.json({ success: true, data })
    }
  } catch (error: any) {
    console.error('Erro inesperado:', error)
    return NextResponse.json(
      { error: 'Erro inesperado ao finalizar conversa' },
      { status: 500 }
    )
  }
}



