import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json(
        { error: 'Não autenticado' },
        { status: 401 }
      )
    }

    // TODO: Verificar se o usuário é admin/suporte
    // Por enquanto, permitir qualquer usuário autenticado responder
    // Você pode adicionar verificação de role/admin aqui

    const { user_id, message } = await request.json()

    if (!user_id || !message || !message.trim()) {
      return NextResponse.json(
        { error: 'user_id e message são obrigatórios' },
        { status: 400 }
      )
    }

    // Salvar resposta do suporte
    const { data, error } = await supabase
      .from('chat_messages')
      .insert([
        {
          user_id: user_id,
          message: message.trim(),
          sender_type: 'support',
          is_read: false
        }
      ])
      .select()
      .single()

    if (error) {
      console.error('Erro ao salvar resposta:', error)
      return NextResponse.json(
        { error: 'Erro ao enviar resposta' },
        { status: 500 }
      )
    }

    return NextResponse.json({ success: true, data })
  } catch (error: any) {
    console.error('Erro inesperado:', error)
    return NextResponse.json(
      { error: 'Erro inesperado ao enviar resposta' },
      { status: 500 }
    )
  }
}



