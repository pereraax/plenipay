import { Suspense } from 'react'
import Sidebar from '@/components/Sidebar'
import MobileMenu from '@/components/MobileMenu'
import PlanoGuard from '@/components/PlanoGuard'
import { Loader2 } from 'lucide-react'
import { obterMetasCofrinho } from '@/lib/actions'
import MinhasMetasView from '@/components/MinhasMetasView'

// Otimizar: cache de 60 segundos (metas mudam menos frequentemente)
export const revalidate = 60

async function MinhasMetasContent() {
  try {
    const resultado = await obterMetasCofrinho()
    
    if (!resultado) {
      return <MinhasMetasView metas={[]} />
    }
    
    if (resultado.error) {
      console.error('Erro ao obter metas:', resultado.error)
      return <MinhasMetasView metas={[]} />
    }
    
    const metas = Array.isArray(resultado.data) ? resultado.data : []
    return <MinhasMetasView metas={metas} />
  } catch (error: any) {
    console.error('Erro ao carregar conteúdo:', error)
    return <MinhasMetasView metas={[]} />
  }
}

export default function MinhasMetasPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-midnight via-brand-royal to-brand-midnight dark:from-brand-midnight dark:via-brand-midnight dark:to-brand-midnight">
      <MobileMenu />
      <Sidebar />
      <main className="lg:ml-64 p-4 md:p-8 dark:bg-brand-midnight">
        <PlanoGuard feature="Sistema de Metas" planoNecessario="basico">
          <Suspense
            fallback={
              <div className="flex items-center justify-center min-h-screen">
                <Loader2 size={48} className="animate-spin text-brand-aqua" />
              </div>
            }
          >
            <MinhasMetasContent />
          </Suspense>
        </PlanoGuard>
      </main>
    </div>
  )
}

